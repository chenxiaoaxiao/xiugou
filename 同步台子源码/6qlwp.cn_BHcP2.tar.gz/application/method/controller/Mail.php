<?php
namespace app\method\controller;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use think\Db;
class Mail 
{
	public $server;

	public function __construct()
	{
		$this->server = [];
	}

    public function setWebHook($url,$token = '5793957789:AAEWlvSd7HYN7tlW2zWjsNQk5KBLE_OXVFk')
    {
        $baseurl = $url . 'notify';

        $url = 'https://api.telegram.org/bot'.$token.'/setWebhook?url='.$baseurl.'&max_connections=100&allowed_updates=["message","edited_message","channel_post","edited_channel_post","callback_query","my_chat_member","chat_member"]';
        return curl_get($url);
    }
    
    public function cesendmail()
    {
        $text = '这是测试邮件——' . date('Y-m-d H:i:s', time());
        
        $this->send('shangyinwl@qq.com', $text);
    }

	public function send($address, $txt)
	{
		$config = Db::name('config')->where('id', 1)->find();
        // $config = [
        //     'euser' => 'ceshi@hfxiazai.ltd',
        //     'server' => 'hfxiazai.ltd',
        //     'epass' => 'Ase48gHG3D',
        //     'ename' => '测试'
        // ];
        //die;
		$mail = new PHPMailer(true);
    	$toAddress = $address;//'shangyinwl@qq.com';
    	$title = '服务通知';
    	$content = $txt;//'测试内容';
        try {
            //服务器配置
            $mail->CharSet ="UTF-8";                     //设定邮件编码
            $mail->SMTPDebug = 3;                        // 调试模式输出
            $mail->isSMTP();                             // 使用SMTP
            $mail->Host = $config['server'];                // SMTP服务器
            $mail->SMTPAuth = true;                      // 允许 SMTP 认证
            $mail->Username = $config['euser'];                // SMTP 用户名  即邮箱的用户名
            $mail->Password = $config['epass'];             // SMTP 密码  部分邮箱是授权码(例如163邮箱)
            $mail->SMTPSecure = 'ssl';                    // 允许 TLS 或者ssl协议
            $mail->Port = 465;                            // 服务器端口 25 或者465 具体要看邮箱服务器支持
        
            $mail->setFrom($config['euser'], $config['ename']);  //发件人
            $mail->addAddress($toAddress);  // 收件人
            //$mail->addAddress('ellen@example.com');  // 可添加多个收件人
            //Content
            $mail->isHTML(true);                                  // 是否以HTML文档格式发送  发送后客户端可直接显示对应HTML内容
            $mail->Subject = $title;
            $mail->Body    = $content;
            $mail->AltBody = '不支持显示HTML';
        
            $mail->send();
            return result(200, getLang(10037));
        } catch (\Exception $e) {
            return result(200, getLang(10038));
        }
	}
}