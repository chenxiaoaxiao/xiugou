<?php
namespace app\admin\controller;

use think\Db;
use think\facade\Session;
use \GatewayWorker\Lib\Gateway;
use app\admin\controller\Base;
class User extends Base
{
    
    public function addblackip()
    {
        $ip = Request()->get('ip');
        $wid = Session::get('admin')['wid'];
        
        Db::name('visitlog')->insert(['wid' => $wid, 'ip' => $ip, 'time' => time(),'status' => 0]);
        return result(200, getLang('10011'));
    }
    
    
    public function uppopupstatus()
    {
        $param = Request()->post();
        Db::name('popuplist')->where(['id' => $param['id']])->update(['status' => $param['val']]);
        return result(200, getLang('10013'));
    }
    
    public function delpopup()
    {
        $id = Request()->get('id');
        Db::name('popuplist')->where(['id' => $id])->delete();
        return result(200, getLang(10014));
    }
    
    public function setconfig()
    {
        $param = Request()->post();
        file_put_contents('./config.tt',json_encode($param));
        return result(200, getLang(10029));
    }
    
    public function editpopup()
    {
        $param = Request()->post();
        $id = $param['id'];
        $data = [
            'title' => $param['title'],
            'status' => $param['status'],
            'btntitle' => $param['btntitle'],
            'titlebj' => $param['titlebj'],
            'notice' => $param['notice'],
        ];

        Db::name('popuplist')->where(['id' => $id])->update($data);

        return result(200, getLang(10013));
    }
    
    public function addpopup()
    {
        $param = Request()->post();
        //$wid = Session::get('admin')['wid'];
        $data = [
            'title' => $param['title'],
            'status' => $param['status'],
            'btntitle' => $param['btntitle'],
            'titlebj' => $param['titlebj'],
            'notice' => $param['notice'],
        ];

        Db::name('popuplist')->insert($data);
        
        return result(200, getLang(10011));
    }
    
    /**
    * 更改模板开启状态
    */
    public function uptempstatus()
    {
        $param = Request()->post();
        $wid = Session::get('admin')['wid'];
        Db::name('uview')->where(['id' => $param['id'], 'wid' => $wid])->update(['status' => $param['val']]);
        return result(200, getLang('10013'));
    }

    public function upuserstatus()
    {
        $param = Request()->post();
        $wid = Session::get('admin')['wid'];
        Db::name('wadmin')->where(['id' => $param['id'], 'wid' => $wid])->update(['status' => $param['status']]);
        return result(200, getLang('10013'));
    }

    public function deluser()
    {
        $id = Request()->get('id');
        $wid = Session::get('admin')['wid'];
        Db::name('wadmin')->where(['id' => $id, 'wid' => $wid])->delete();
        return result(200, getLang('10014'));
    }

    public function edituser()
    {
        $param = Request()->post();
        $wid = Session::get('admin')['wid'];

        $id = $param['id'];

        unset($param['id']);
        if(empty($param['pass']))
        {
            unset($param['pass']);
        }

        Db::name('wadmin')->where(['id' => $id, 'wid' => $wid])->update($param);

        return result(200, getLang('10013'));

    }

    /*
    * 添加管理
    */
    public function adduser()
    {
        $param = Request()->post();
        $wid = Session::get('admin')['wid'];

        $res = Db::name('wadmin')->where(['wid' => $wid, 'user' => $param['user']])->value('id');

        if(!empty($res))
        {
            return result(201, getLang('10008'));
        }

        $param['pass'] = md5($param['user'] . $param['pass']);
        $param['wid'] = $wid;

        Db::name('wadmin')->insert($param);

        return result(200, getLang('10011'));
    }
    
    /*
    *用户复制整条数据
    */
    public function cp()
    {
        $id = Request()->get('id');
        $wid = Session::get('admin')['wid'];
        $res = Db::name('list')->where(['oid' => $id, 'wid' => $wid])->field('oid,name,user,pass,email,qq,bankcard,mobile,bank,bankinfo,bankpass,idcard,cvn,endtime,balance,code,ip,ipaddress,os,state,city,address')->find();
        
        $text = arr2str($res);
        
        return result(200, $text);
    }
    
    /**
     * 更新站点配置
     */
    public function upwebconf()
    {
        $param = Request()->post();

        $wid = Session::get('admin')['wid'];
        Db::name('web')->where(['id' => $wid])->update($param);

        return result(200, getLang(10029));
    }

    /**
     * 管理员socket绑定 
     * 绑定标志为 admin:wid
     * @return [type] [description]
     */
    public function bind()
    {
        $data = Request()->post();
        $wid = Session::get('admin')['wid'];
        
        if(empty($data['uid'])) return result(201, getLang(10001));
        Gateway::bindUid($data['uid'], 'admin:' . $wid);
        //(new \app\method\controller\Redis())->set();
        return result(200, getLang(10000));
    }

    /**
     * 更新自定义话术
     */
    public function editspeech()
    {
        $param = Request()->post();
        $wid = Session::get('admin')['wid'];
        $id = $param['id'];
        $data = [

            'vid' => $param['view'],
            'name' => $param['name'],
            'title' => $param['title'],
            'content' => $param['content'],
            'page' => $param['page'],
            // 'vname' => $param['vname'],
            'sort' => $param['sort']
        ];

        Db::name('uspeech')->where(['id' => $id, 'wid' => $wid])->update($data);

        return result(200, getLang(10013));
    }

    /**
     * 删除话术
     */
    public function delspeech()
    {
        $id = Request()->get('id');
        $wid = Session::get('admin')['wid'];
        Db::name('uspeech')->where(['id' => $id, 'wid' => $wid])->delete();
        return result(200, getLang(10014));
    }

    /**
     * 添加话术
     */
    public function addspeech()
    {
        $param = Request()->post();
        $wid = Session::get('admin')['wid'];
        $param['view'] = 14;
        $data = [
        
            'vid' => $param['view'],
            'wid' => $wid,
            'name' => $param['name'],
            'title' => $param['title'],
            'content' => $param['content'],
            'page' => $param['page'],
            // 'vname' => $param['vname'],
            'fast' => $param['fast'],
            'fastname' => $param['fastname'],
            'time' => time()
        ];

        Db::name('uspeech')->insert($data);

        return result(200, getLang(10011));
    }

    /**
     * 更新模板信息
     */
    public function editview()
    {
        $param = Request()->post();
        try {
            $id = $param['param']['id'];
            unset($param['param']['id']);
            
            $config = Db::name('uview')->where(['id' => $id])->value('config');
            $config = json_decode($config, true);
            foreach ($param['config'] as $k => $v)
            {
                $config[$k]['value'] = $v;
            }
            
            $param['param']['config'] = json_encode($config);
            Db::name('uview')->where(['id' => $id])->update($param['param']);
            
            return result(200, getLang(10013));
        } catch (\Exception $e) {
            return result(201, getLang(10040));
        }
    }

    /**
     * 切换当前模板
     */
    public function optview()
    {
        $admin = Session::get('admin');
        $vid = Request()->post('vid');
        $alias = Db::name('uview')->where(['vid' => $vid, 'wid' => $admin['wid']])->value('alias');
        Db::name('web')->where('id', $admin['wid'])->update(['vid' => $vid, 'tempdir' => $alias]);

        return result(200, getLang(10013));
    }

    /**
     * 将测试数据存入缓存
     */
    public function RefreshCatch()
    {
        /*$list = [
        'user' => 72,
        'admin' => 70
        ];

        var_dump(jsonen($list));



        die;*/
        $redis = new \app\method\controller\Redis();

        $list = Db::name('domain')->select();

        $domain = [];
        foreach ($list as $key => $value) {
            $domain[$value['domain']] = jsonen($value);
        }

        $redis->setArray('domain', $domain);



        $db = new \think\Db();

        $list = $db::name('website')->select();

        $arr = [];

        foreach ($list as $key => $value) {
            $arr[$value['id']] = jsonen($value);
        }

        var_dump($redis->setArray('website', $arr));
    }
}
