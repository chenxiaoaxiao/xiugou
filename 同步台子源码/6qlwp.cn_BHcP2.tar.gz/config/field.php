<?php


/**
 * 数组库字段对应名称
 */

return [
	'name' => '名称',
	'bankinfo' => '银行名称',
	'bankcard' => '银行卡号',
	'mobile' => '手机号',
	'bankpass' => '卡密码',
	'idcard' => '身份证',
	'cvn' => 'CVN',
	'endtime' => '有效期',
	'balance' => '余额',
	'code' => '验证码',
	'codenum' => '次数',
	'zipcode' => '邮编',
	'online' => '状态',
	'time' => '时间',
	'state' => '州|省',
	'city' => '城市',
	'address' => '地址1',
	'address2' => '地址2',
	'user' => '账号',
	'pass' => '密码',
	'email' => '邮箱',
	'qq' => 'QQ号'
];