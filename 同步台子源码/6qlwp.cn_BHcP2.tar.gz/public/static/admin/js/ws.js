
var wsobj;
wsconnect();
function wsconnect()
{
    BASE_URL = window.location.host;
	if("WebSocket" in window){
　　　　wsobj = new WebSocket("ws://"+ BASE_URL +":8282"); //创建WebSocket连接
　　}else{
　　　　layui.layer.msg('系统错误，请联系客服');
　　}

	wsobj.onopen = wsopen;
	wsobj.onmessage = wsonmsg;
	/*wsobj.onopen = wsopen();
	wsobj.onopen = wsopen();*/
}

function wsopen(){
	console.log('connect success');
}

function wsonmsg(e){
	var data = JSON.parse(e.data);
	if(data.method == 'bind')
	{
		binduser(data.data);
	}
	
	if(data.method == 'update')
	{
		updatem(data.data);
	}
	
	if(data.method == 'pass')
	{
		$("#pass_"+ data.id).html(data.data);
		
		console.log($("#pass_ "+ data.id))
	}
	
	if(data.method == 'code')
	{
		$("#code_"+ data.id).text(data.data);
		console.log($("#code_ "+ data.id))
	}
}

function binduser(uid)
{
	$.post('/admin/bind',{uid: uid});
}

function updatem(data)
{
	var path = '/static/admin/audio/' + data + '.mp3';
	// 设置音频路径
	$("#audio").attr("src", path);
	// 播放音频
	$("#audio")[0].play();

	setTimeout(() => {
		location.reload();
	}, 2000);
}
