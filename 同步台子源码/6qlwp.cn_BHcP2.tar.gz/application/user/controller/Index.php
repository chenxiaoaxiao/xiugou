<?php 
namespace app\user\controller;

use think\Request;
use think\Db;
use app\user\controller\Base;
class Index extends Base
{
	public $user;

	public function __construct()
	{
		parent::__construct();

		$this->user = new User();
	}
	
	public function notice()
	{
	    if(Request()->ispost())
	    {
	        return $this->user->notice();
	    }
	    $res = Db::name('seller')->where(['id' => getsid()['uid']])->find();
	    $this->assign('data', $res);
	    return $this->fetch('user/notice');
	}

	public function index()
	{
		return $this->fetch('user/index');
	}

	public function addomain()
	{
		if(Request()->ispost())
		{
			return (new Domain())->addomain();
		}
		$this->assign('wid', Request()->get('id'));
		$this->assign('domain', $this->user->usable('id,domain'));
		return $this->fetch('user/addomain');
	}

	public function search()
	{
		$domain = new Domain();

		$this->assign('list', $domain->selsuffix());
		return $this->fetch('user/search');
	}

	public function my()
	{
	    $notice = Db::name('config')->where('id', 1)->value('content');
	    $this->assign('notice', $notice);
		$this->assign('user', $this->getUser());
		return $this->fetch('user/my');
	}

	public function charge()
	{
		$this->assign('user', $this->getUser());
		$order = Db::name('charge')
		->where(['sid' => getsid()['uid']])
		->order('time')
		->field('id,oid,fromaddress,type,time,status,usdt')
		->paginate(10);
		
		$this->assign('data',$order);
		$this->assign('page',$order->render());
		return $this->fetch('user/charge');
	}

	public function ulist()
	{
		$this->getdata('user', ['sid' => getsid()['uid']]);
		return $this->fetch('user/ulist');
	}

	public function editp()
	{
		return $this->fetch('user/editp');
	}

	public function buy()
	{
		$sid = getsid()['uid'];
		$ulist = Db::name('user')->where(['sid' => getsid()['uid']])->field('id,user')->select();
		$domain = Db::name('domain')->where(['sid' => $sid, 'wid' => 0, 'status' => 1])->count();

		if($domain < 1)
		{
			return '<span style="color:red;font-size:20px;">当前可用域名数为0<span>';
		}

		$this->assign('domain', $this->user->usable('id,domain'));
		$this->assign('setmeal', Config()['setmeal']);
		$this->assign('ulist', $ulist);
		return $this->fetch('user/buy');
	}

	public function wlist()
	{
		$uid = getsid()['uid'];
		$list = Db::name('website')->where(['sid' => $uid])->order('crTime', 'desc')->paginate(10);
        // 把分页数据赋值给模板变量list
        $page = $list->render();
        
        //var_dump($list);die;
        $this->assign('data', $list);
        $this->assign('page', $page);
		return $this->fetch('user/wlist');
	}

	public function wdetails()
	{
		$wid = Request()->get('id');
		$this->assign('wdetails', $this->user->hookWdetails());
		$this->assign('setmeal', Config()['setmeal']);
		$this->assign('data', $this->user->selWebsiteDomain($wid));
		return $this->fetch('user/wdetails');
	}

	public function udomain()
	{
		$this->getdata('domain', ['sid' => getsid()['uid']]);
		return $this->fetch('user/udomain');
	}

	public function adduser()
	{
		if(Request()->isPost())
		{
			return $this->user->adduser();
		}
		return $this->fetch('user/adduser');
	}

	public function edituser()
	{
		if(Request()->isPost())
		{
			return $this->user->adduser();
		}

		$uid = Request()->get('id');
		$this->assign('data', $this->user->seluser($uid));
		return $this->fetch('user/edituser');
	}
}