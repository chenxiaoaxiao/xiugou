<?php
namespace app\user\controller;

use think\Controller;
use think\Db;
/**
* 公共类
*/
class Base extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$user = getSid();
		$token = getSid('seller_toekn');
        //var_dump(APP_PATH);die;
        //var_dump($token);die;
		if(empty($user) || empty($token) || checkPass($user['uid'], $user['user']) !== $token)
		{
			$this->redirect('/user/login');
		}
	}

	public function getUser()
	{
		$uid = getSid()['uid'];
		return Db::name('seller')->where('id', $uid)->find();
	}

	public function getdata($name, $where, $field = '')
	{
		$order = Db::name($name)
		->where($where)
		->order('crTime', 'desc')
		//->field($field)
		->paginate(10);
		
		$this->assign('data',$order);
		$this->assign('page',$order->render());
	}

	public function delone($name, $where)
	{
		return Db::name($name)->where($where)->delete();
	}
}