<?php
namespace app\user\controller;

use think\Db;
use think\facade\Request;
use think\facade\Session;
use app\user\controller\Base;
use app\method\controller\Sql;
use think\facade\Config;
class Domain extends Base
{

	public function selsuffix()
	{
		$res = Db::name('dtype')->field('value,name')->select();
		$list = [];
		foreach ($res as $key => $value) {
			$list[$value['name']] = $value['value'];
		}
		return $list;
		//var_dump($list,Config::get('domain.'));die;
		//return $domainlist = Config::get('domain.');
	}

	/**
	 * 站点添加域名
	 */
	public function addomain()
	{
		$param = file_get_contents("php://input");

		$param = json_decode($param,true);

		$wid = (int)$param['id'];
		$sid = getsid()['uid'];
		$domain = $param['vals'];

		$usable = (new user())->usable('id');

		if(empty($usable))
		{
			return result(201, getLang(10024));
		}

		$usable = arrgetkey($usable, 'id');

		Db::startTrans();

		try {
			foreach ($domain as $value) {
				if(!in_array($value, $usable))
				{
					return result(201, getLang(10025));
				}

				if(!Db::name('domain')->where(['sid' => $sid, 'id' => $value])->update(['wid' => $wid]))
				{
					Db::rollback();
					return result(201, getLang(10026));
				}
			}

			Db::commit();
			return result(200, getLang(10011));
		} catch (\Exception $e) {
			Db::rollback();
			WriteExceptionInformation($e);
			return result(201, getLang(10026));
		}
	}

	/**
	 * 域名申请|注册
	 */
	public function logon()
	{
		$param = file_get_contents("php://input");

		$param = json_decode($param,true);

		$Premium = 10;
		$suffix = Db::name('dtype')->select();
		$dtype = [];
		foreach ($suffix as $v) {
			$dtype[$v['value']] = $v;
		}
		$sid = getSid()['uid'];
		$list = [];
		$count_money = 0;
		//计算金额
		foreach ($param as $b) {
			$count_money = $count_money + (int)$dtype[$b['suffix']]['money'] + $Premium;
			//组装申请域名
			$list[] = [
				'sid' => $sid,
				'domain' => $b['domain'],
				'money' => (int)$dtype[$b['suffix']]['money'],
				'crTime' => time()
			];
		}

		//开启事务
		Db::startTrans();

		try {
			$seller = Db::name('seller')->where(['id' => $sid])->lock(true)->find();
			if($seller['money'] < $count_money)
			{
				return result(201, getLang(10004));
			}

			//更新余额
			if(!Db::name('seller')->where(['id' => $sid])->update(['money' => $seller['money'] - $count_money]))
			{
				Db::rollback();
				return result(201, getLang(10002));
			}
			
			if(!Db::name('domain')->insertAll($list))
			{
				Db::rollback();
				return result(201, getLang(10002));
			}

			Db::commit();
			return result(200, getLang(10003));
		} catch (\Exception $e) {
			Db::rollback();
			WriteExceptionInformation($e);
			return result(201, getLang(10002));
		}
	}

	/**
	 * 查询可注册域名
	 */
	public function seldomain()
	{
		try {
			$Premium = 10;
			$suffix = Db::name('dtype')->select();
			$dtype = [];
			foreach ($suffix as $value) {
				$dtype[$value['value']] = $value;
			}

			$param = Request()->post();
			$array = [];

			foreach ($param['suffix'] as $value) {
				//$res = checkdomain($param['domain'] . $value);
                
                $array[] = [
                    'name' => $param['domain'] . $value,
                    'money' => $dtype[$value]['money'] + $Premium,
                    'suffix' => $value
                ];
				//var_dump($res);die;
				// if(!empty($res->original))
				// {
				// 	if(strpos($res->original, '210') !== false)
				// 	{
				// 		$array[] = [
				// 			'name' => $param['domain'] . $value,
				// 			'money' => $dtype[$value]['money'] + $Premium,
				// 			'suffix' => $value
				// 		];
				// 	}
				// }
			}

			return result(200, getLang(10000), $array);

		} catch (\Exception $e) {
			WriteExceptionInformation($e);
			return result(201, getLang(10001));
		}
		
	}
	
}
