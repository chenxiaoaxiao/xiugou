<?php

/**
 * 系统域名后缀大全
 */

return [

	'com' => '.com',
	'net' => '.net',
	'xyz' => '.xyz',
	'inc' => '.inc',
	'lol' => '.lol',
	'org' => '.org',
	'tv' => '.tv',
	'co' => '.co',
	'biz' => '.biz',
	'one' => '.net',
	'info' => '.info',
	'cc' => 'cc'
];