<?php
namespace app\method\controller;

use think\Db;

class Login
{
	
	public function login($pass ,$salt, $ypass)
	{
		
	}
}