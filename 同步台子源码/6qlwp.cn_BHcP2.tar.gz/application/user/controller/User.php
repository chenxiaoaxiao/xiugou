<?php
namespace app\user\controller;

use think\Db;
use think\facade\Request;
use think\facade\Session;
use app\user\controller\Base;
use app\method\controller\Sql;
class User extends Base
{

	public $minU;

	public function __construct()
	{
		parent::__construct();
		$this->minU = 20;
	}
	
	public function notice()
	{
	    $param = Request()->post();
	    $res = Db::name('seller')->where(['id' => getsid()['uid']])->update($param);
	    return result(200, getLang(10029));
	}

	/**
	 * 商户端删除站点域名
	 */
	public function deldomain()
	{
		$param = Request()->post();

		Db::name('domain')->where(['id' => $param['rid'],'wid' => $param['wid']])->update(['wid' => 0]);

		return result(200, getLang(10014));
	}

	/**
	 * 查询站点下所有域名
	 */
	public function selWebsiteDomain($wid)
	{
		return Db::name('domain')->where(['wid' => $wid])->select();
	}

	/**
	 * 获取当前商户可用域名
	 * @return [type] [description]
	 */
	public function usable($field)
	{
		$sid = getsid()['uid'];
		return Db::name('domain')->where(['sid' => $sid, 'wid' => 0, 'status' => 1])->field($field)->select();
	}

	/**
	 * 站点续费
	 */
	public function renew()
	{
		$param = Request()->post();
		$sid = getsid()['uid'];
		$Package = Config()['setmeal'];
		//$website = Db::name('website')->where(['id' => $param['wid'], 'sid' => $sid])->field()
		Db::startTrans();
		try {
			$umoney = Db::name('seller')->where(['id' => $sid])->value('money');
			$money = $Package[$param['time']];
			if($umoney < $money)
			{
				return result(201, getLang(10004));
			}

			Db::name('seller')->where(['id' => $sid])->update(['money' => $umoney-$money]);

			//更新到期时间
			$endtime = $param['time'] * 60 * 60 * 24;
			if(!Db::name('website')->where(['id' => $param['wid']])->setInc('endTime', $endtime))
			{
				Db::rollback();
				return result(201, getLang(10022));
			}

			Db::commit();
			return result(200, getLang(10023));
		} catch (\Exception $e) {
			Db::rollback();
			WriteExceptionInformation($e);
			return result(201, getLang(10022));
		}
	}

	/**
	 * 获取站点详细信息
	 */
	public function hookWdetails()
	{
		$wid = Request()->get('id');
		$sid = getsid()['uid'];

		$website = Db::name('website')->where(['id' => $wid, 'sid' => $sid])->find();

		return $website;
	}

	/**
	 * 更新商户密码
	 */
	public function uppass()
	{
		$param = Request()->post();
		$sid = getSid()['uid'];

		$user = Db::name('seller')->where(['id' => $sid])->field('pass, salt')->find();

		if(checkPass($param['pass'], $user['salt']) !== $user['pass'])
		{
			return result(201, getLang(10019));
		}

		Db::name('seller')->where(['id' => $sid])->update(['pass' => checkPass($param['passx'], $user['salt'])]);
		$this->logout();
		return result(200, getLang(10013));
	}

	/**
	 * 开通站点
	 */
	public function opening()
	{

		$param = Request()->post();
		$uid = getsid()['uid'];
		//自定义套餐
		$Package = Config()['setmeal'];

		Db::startTrans();
		
		try {
			//判断余额
			$umoney = Db::name('seller')->where(['id' => $uid])->lock(true)->field('money')->find();
			$money = $Package[$param['time']];

			if($umoney['money'] < $money)
			{
				return result(201, getLang(10004));
			}

			//判断域名
			$usable = $this->usable('id');

			if(empty($usable))
			{
				return result(201, getLang(10024));
			}

			$usable = arrgetkey($usable, 'id');

			foreach ($param['domain'] as $value) {
				if(!in_array($value, $usable))
				{
					return result(201, getLang(10025));
				}
			}

			//更新余额
			Db::name('seller')->where(['id' => $uid])->update(['money' => $umoney['money']-$money]);

			//创建新站点
			$indata = [
				'endTime' => time() + ($param['time'] *24*60*60),
				'remarks' => $param['remarks'],
				'uid' => json_encode([$param['user'] => (int)$param['uid']]),
				'sid' => $uid,
				'crTime' => time(),
				'upTime' => time(),
				'usdt' => $money,
			];
			
			$wid = Db::name('website')->insertGetId($indata);
			if(!$wid)
			{
				Db::rollback();
				return result(201, getLang(10021));
			}


			//循环更新域名
			foreach ($param['domain'] as $value) {
				if(!Db::name('domain')->where(['sid' => $uid, 'id' => $value])->update(['wid' => $wid]))
				{
					Db::rollback();
					return result(201, getLang(10026));
				}
			}

			//复制模板表，话术表
			$view = Db::name('view')->select();
			$speech = Db::name('speech')->field('id', true)->select();

			foreach ($view as $key => $value) {
				$view[$key]['wid'] = $wid;
				$view[$key]['vid'] = $value['id'];
				unset($view[$key]['id']);
			}

			foreach ($speech as $key => $value) {
				$speech[$key]['wid'] = $wid;
			}

			if(!Db::name('uview')->insertAll($view))
			{
				Db::rollback();
				return result(201, getLang(10021));
			}
			if(!Db::name('uspeech')->insertAll($speech))
			{
				Db::rollback();
				return result(201, getLang(10021));
			}

			Db::commit();
			return result(200, getLang(10015));

		} catch (\Exception $e) {
			Db::rollback();
			WriteExceptionInformation($e);
			return result(201, getLang(10021));
		}
	}

	/**
	 * 创建充值
	 */
	public function createpay()
	{
		$u = Request::get('u');
		if($u < $this->minU)
		{
			return result(201, getLang(10016));
		}

		$sobj = getSid();
		$data = [
			'oid' => date('YmdHis') . rand(1000,9999),
			'sid' => $sobj['uid'],
			'usdt' => $u,
			'type' => 1,
			'time' => time()
		];

		$id = Db::name('charge')->insertGetId($data);
		if(!$id)
		{
			return result(201, getLang(10017));
		}

		return result(200, getLang(10018), ['oid' => $id]);

	}

	/**
	 * usdt充值
	 */
	public function upay()
	{
		$oid = Request::get('oid');

		$user = getSid();
		if(empty($oid)) return result(201, getLang(10001));

		$uorder = Db::name('charge')->where(['id' => $oid,'sid' => $user['uid']])->find();

		if(empty($uorder)) return result(201, getLang(10001));

		$this->assign('data', [
			'oid' => $uorder['oid'],
			'usdt' => $uorder['usdt'],
			'address' => 'TUqsNowc4vEKZfA289Ct5o4eY6N1gJCPc3',
			'id' => $uorder['id']

		]);

		return $this->fetch('user/upay');
	}


	public function userlist()
	{
		$param = Request::get();

		$order = DB::name('user')
		->where(['sid' => getsid()['uid']])
		->select();

		$count = count($order);
		
		$order = Db::name('user')
		->where(['sid' => getsid()['uid']])
		->order('time', 'desc')
		->limit($param['limit'])
		->page($param['page'])
		->select();

		//$list = $order->limit($param['limit'])->page($param['page']);
		$data = [

			'code' => 0,
			'msg' => '',
			'count' => $count,
			'data' => $order
		];

		return json($data);
	}

	public function logout()
	{
		Session::clear();
        return result(200, getLang(10012));
	}

	/**
	 * 商户添加登录账户
	 */
	public function adduser()
	{
		$param = Request()->post();
		$salt = rand_str(10);

		$res = Db::name('user')->where(['sid' => getsid()['uid'], 'user' => $param['user']])->value('user');

		if($res !== null)
		{
			return result(201, getLang(10008));
		}

		$data = [

			'sid' => getsid()['uid'],
			'user' => $param['user'],
			'pass' => checkPass($param['pass'], $salt),
			'salt' => $salt,
			'mpass' => $param['pass'],
			'crTime' => time(),
			'remarks' => $param['remarks'],
		];

		Db::name('user')->insert($data);

		return result(200, getLang(10011));
	}

	/**
	 * 更新自定义账户信息
	 */
	public function upuser()
	{
		$data = Request()->Post();

		$uid = $data['id'];

		unset($data['id']);

		if(!empty($data['pass']))
		{
			$data['mpass'] = $data['pass'];
			$data['salt'] = rand_str(10);
			$data['pass'] = checkPass($data['mpass'], $data['salt']);
		}
		Db::name('user')->where(['id' => $uid])->update($data);

		return result(200, getLang(10013));
	}

	/**
	 * 删除自定义用户
	 */
	public function deluser()
	{

		$uid = Request()->get('id');

		$this->delone('user', ['id' => $uid]);

		return result(200, getLang(10014));
	}

	/**
	 * 根据uid查找用户自定义账户信息
	 */
	public function seluser($uid)
	{

		return Db::name('user')->where(['id' => $uid])->find();
	}
}