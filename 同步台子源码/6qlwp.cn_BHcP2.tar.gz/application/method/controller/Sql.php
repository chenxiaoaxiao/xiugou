<?php 
namespace app\method\controller;

use think\Db;

/**
*  数据库简便操作类
*/
class Sql
{
	
	public function __construct()
	{

	}

	

	/**
	 * 查询一条数据
	 */
	public function Find($name, $where = [])
	{
		return Db::name($name)->where($where)->find();
	}

	/**
	 * 插入一条数据
	 */
	public function insert($name, $data)
	{
		return Db::name($name)->insert($data);
	}

	/**
	 * 插入一条数据并获取id
	 */
	public function insertGetId($name, $data)
	{
		return Db::name($name)->insertGetId($data);
	}

	public function select($name, $where)
	{
		return Db::name($name)->where($where)->select();
	}

	/**
	 * 插入访问日志
	 */
	public function insertVisitLog($name, $data)
	{
		$id = Db::name($name)->where(['ip' => $data['ip']])->value('id');

		if(empty($id))
		{
			Db::name($name)->insert($data);
		}else{
			Db::name($name)->where(['id' => $id])->SetInc('num');
		}
	}

	/**
	 * 根据id删除一条数据
	 * @param  [type] $name [库名]
	 * @param  [type] $id   [主键]
	 */
	public function delfind($name, $id)
	{
		if(Db::name($name)->delete($id))
		{
			return result(200, 'success');
		}else{
			return result(201, 'error');
		}
	}
}

