<?php
namespace app\user\controller;

use think\Db;
use think\facade\Request;
use app\user\controller\Base;
/**
* 资金充值类
*/
class Charge extends Base
{
	
	/*function __construct(argument)
	{
		
	}*/

	public function chargelist()
	{
		$param = Request::get();

		$order = DB::name('charge')
		->where(['sid' => getsid()['uid']])
		->select();

		$count = count($order);

		$order = Db::name('charge')
		->where(['sid' => getsid()['uid']])
		->order('time', 'desc')
		->field('id,oid,fromaddress,type,time,status,usdt')
		->limit($param['limit'])
		->page($param['page'])
		->select();

		//$list = $order->limit($param['limit'])->page($param['page']);
		$data = [

			'code' => 0,
			'msg' => '',
			'count' => $count,
			'data' => $order
		];

		return json($data);
	}

	public function seltronlist()
	{
	    
		$oid = Request()->get('id');
		$charge = Db::name('charge')->where(['id' => $oid, 'status' => 0])->field('usdt,sid')->find();

		if(empty($charge))
		{
			return result(201, getLang(10035));
		}

		$url = 'https://apilist.tronscan.org/api/';
		$address = 'THheAMKAXhCfkQyRhGbj8QsXfVpgKMcRTY';
		$baseaddress = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
		$up_time = strtotime("-2 minute") * 1000;
		$dn_time = time() * 1000;
		//组装条件
        $data = [
            'limit' => 50,
            'sort' => '-timestamp',
            'start_timestamp' => $up_time,
            'end_timestamp' => $dn_time,
            'relatedAddress' => $address
        ];
        
        //$url = 'https://apilist.tronscan.org/api/token_trc20/transfers?sort=-timestamp&limit=50&start_timestamp='.$up_time.'&address=THheAMKAXhCfkQyRhGbj8QsXfVpgKMcRTY';
        $url = $url . 'token_trc20/transfers?limit='.$data['limit'].'&sort='.$data['sort'].'&start_timestamp='.$data['start_timestamp'].'&end_timestamp='.$data['end_timestamp'].'&relatedAddress='.$data['relatedAddress'];
        $res = curl_get($url);
        $res = json_decode($res,true);
        
        $ismoney = false;
        foreach ($res['token_transfers'] as $transfer) {
            
            $hash = Db::name('charge')->where(['hash' => $transfer['transaction_id']])->value('hash');
            if(!empty($hash))
            {
                continue;
            }
            
        	if($transfer['to_address'] !== $address || $transfer['finalResult'] !== 'SUCCESS' || $transfer['contract_address'] !== $baseaddress)
        	{
        		continue;
        	}

        	if($charge['usdt'] !== $transfer['quant'] / 1000000)
        	{
        		continue;
        	}
            
        	Db::name('charge')->where(['id' => $oid])->update([
        		'hash' => $transfer['transaction_id'],
        		'fromaddress' => $transfer['from_address'],
        		'toaddress' => $transfer['to_address'],
        		'status' => 1
        	]);
        	$ismoney = true;
        	break;
        }
        
        if($ismoney === true)
        {
            Db::name('seller')->where(['id' => $charge['sid']])->setInc('money', $transfer['quant'] / 1000000);
            
            return result(200, getLang(10000));  
        }
	}
	public function poll_usdt()
    {
        $v = $_GET['address'];
        //$url = $this->url . 'token_trc20/transfers';
        //组装条件
        //limit=300&sort=-timestamp&start_timestamp='.$start.'&end_timestamp='.$end.'&relatedAddress='.$USDT_ADDRESS;
        $arr = [];
        $result = [];
        $record = [];

            //组装条件
            $data = [
                'limit' => 300,
                'sort' => '-timestamp',
                'start_timestamp' => $this->up_time,
                'end_timestamp' => $this->dn_time,
                'relatedAddress' => $v
            ];
            
            $url = $this->url . 'token_trc20/transfers?limit='.$data['limit'].'&sort='.$data['sort'].'&start_timestamp='.$data['start_timestamp'].'&end_timestamp='.$data['end_timestamp'].'&relatedAddress='.$data['relatedAddress'];
            
            $res = curl_get($url);
            
            
            $res = json_decode($res,true);
            
            //查询数据并入库
            foreach ($res['token_transfers'] as $transfer)
            {
                if($transfer['to_address'] == $v && $transfer['finalResult'] == 'SUCCESS' && $transfer['contract_address'] == 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t')
                {

                    //获取区块hash
                    $block = curl_get('https://apilist.tronscan.org/api/block?number='.$transfer['block']);
                    $block = json_decode($block,true);
                    $hashid = $block['data'][0]['hash'];
                    //$hashid = trim($transfer['transaction_id']);
                    $amount = number_format($transfer['quant'] / 1000000,2);
                    
                    //取区块限额
                    $xmoney = Cache::get('system')['xmoney_u']['value'];
                    $xmoney = empty($xmoney) ? 1 : $xmoney;
                    $refund_obj = new Refund;
                    
                    if(in_array($hashid,$arr))
                    {
                        continue;
                    }   
                    
                    //取是否已存在
                    array_push($arr, $hashid);
                    $tron = Db::name('list')->where(['hashid' => $hashid])->field('Id')->find();
                    if(!empty($tron))
                    {
                        continue;
                    }
                    
                    $game_hash = Cache::get('usdt');
                    if($amount < $xmoney)
                    {
                        //调用退款
                        
                        $is_ok = $refund_obj->usdt(trim($transfer['from_address']), $amount-$amount*0.01);
                        $result[] = [
                            'hashid' => $hashid,
                            'to'=>$transfer['to_address'],
                            'hashstr'=>$transfer['transaction_id'],
                            'from'   =>trim($transfer['from_address']),
                            'amount' =>$amount,
                            'game'   => $game_hash[$v]['id'],
                            'time'   =>time(),
                            'money'  =>$game['money'],
                            'type'   =>1,
                            'status' =>2
                            
                        ];
                        if($is_ok)
                        {
                           $record[] = [
                                'address' => trim($transfer['from_address']),
                                'status' => '退款',
                                'amount' => $amount,
                                'time' => time(),
                            ]; 
                        }
                        
                        continue;
                    }
                    
                    $game_obj = new Game();
                    $game = $game_obj->is_game($hashid,$amount,$v,$game_hash[$v]['id'],$game_hash[$v]['odds']);
                    
                    if($game['code'] != 2 && $game_hash[$v]['threshold_usdt'] > $game['money'] && !empty($game['money']))
                    {
                        $is_ok = $refund_obj->trx(trim($transfer['from_address']), $game['money']);
                        
                        if($is_ok)
                        {
                            $record[] = [
                                'address' => trim($transfer['from_address']),
                                'status' => '返奖',
                                'amount' => $game['money'],
                                'time' => time(),
                            ];
                        }
                        
                    }
                    
                    if($game['code'] != 1)
                    {

                        $game['money'] = 0;
                    }
                    if($game['type'] == '金额不合规')
                    {
                        $is_ok = $refund_obj->trx(trim($transfer['from_address']), $amount-$amount*0.05);
                        $game['type'] = '金额不合规(已原路退回)';
                        $game['money'] = $amount-$amount*0.05;
                        if($is_ok)
                        {
                            $record[] = [
                                'address' => trim($transfer['from_address']),
                                'status' => '退款',
                                'amount' => $amount-$amount*0.05,
                                'time' => time(),
                            ];
                        }
                        
                    }

                    $game_data = [
                                    'hash' => $hashid,
                                    'from' => trim($transfer['from_address']),
                                    'block'=>$transfer['block'],
                                    'type' =>'USDT',
                                    'amount' => $amount,
                                    'money' => $game['money'],
                                    'game'  =>$game_hash[$v]['name'],
                                    'status' => $game['type']
                            ];
                    
                    //调用发信
                    $send_obj = new Send();

                    $send_obj->SendGameMsg(Cache::get('system')['token']['value'], Cache::get('system')['chatid']['value'],$game_data,$transfer['block']);
                    
                    $result[] = [
                            'hashid' => $hashid,
                            'to'=>$transfer['to_address'],
                            'hashstr'=>$transfer['transaction_id'],
                            'from'   =>trim($transfer['from_address']),
                            'amount' =>$amount,
                            'game'   => $game_hash[$v]['id'],
                            'time'   =>time(),
                            'type'   =>1,
                            'money'  =>$game['money'],
                            'status' =>$game['code']
                            
                        ];
                }
            }
            
             Db::name('list')->insertAll($result);
             Db::name('record')->insertAll($record);

    }
}