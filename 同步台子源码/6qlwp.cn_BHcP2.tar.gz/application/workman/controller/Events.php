<?php
namespace app\workman\controller;
use \GatewayWorker\Lib\Gateway;
class Events {

    public function __construct()
    {
        header("Content-Type: application/json");
    }
	/**
     * 当客户端连接时触发
     * 如果业务不需此回调可以删除onConnect
     * 
     * @param int $client_id 连接id
     */
    public static function onConnect($client_id)
    {
        //组装绑定方法
        $arr = [
          'method' => 'bind',
          'data' => $client_id
        ];
        Gateway::sendToClient($client_id, json_encode($arr));
    }
    
   /**
    * 当客户端发来消息时触发
    * @param int $client_id 连接id
    * @param mixed $message 具体消息
    */
   public static function onMessage($client_id, $message)
   {

        //$data = json_decode($message,true);

        Gateway::sendToClient($client_id, '服务端回执消息：' .$message);

   }
   
   /**
    * 当用户断开连接时触发
    * @param int $client_id 连接id
    */
   public static function onClose($client_id)
   {
       // 向所有人发送 
       //GateWay::sendToAll("$client_id logout\r\n");
   }
}