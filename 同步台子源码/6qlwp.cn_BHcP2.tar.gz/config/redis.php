<?php



/**
 * Redis操作配置文件
 */

return [

	'host' => '127.0.0.1',

	'port' => '6379',

	'pass' => 'qianduoduo'
];