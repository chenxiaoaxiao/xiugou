<?php
namespace app\user\controller;

use think\Controller;
use think\facade\Request;
use think\Db;
use think\facade\Session;
use app\method\controller\Base;
class Login extends Base
{
	public function index()
	{
		if(Request::ispost()){
			return $this->login();
		}
		return $this->fetch('user/login');
	}

	public function register()
	{
		if(Request()->ispost())
		{
			$code = 10000;
			$param = Request()->post();

			if(empty($param['user']) || empty($param['pass']) || empty($param['pass']) || empty($param['code']))
			{
				return result(201, getLang(10005));
			}

			if($param['pass'] !== $param['pass2'])
			{
				return result(201, getLang(10006));
			}

			if($param['code'] !== (string)$code)
			{
				return result(201, getLang(10007));
			}

			$res = Db::name('seller')->where(['user' => $param['user']])->value('user');
			if(!empty($res))
			{
				return result(201, getLang(10008));
			}

			$salt = rand_str();
			$data = [
				'user' => $param['user'],
				'pass' => checkPass($param['pass'], $salt),
				'salt' => $salt,
				'crTime' => time(),
				'ip' => getIp()
			];

			if(Db::name('seller')->insert($data))
			{
				return result(200, getLang(10009));
			}

			return result(201, getLang(10010));
		}

		return $this->fetch('user/register');
	}

	public function login()
	{
		$post = Request::post();
		if(empty($post['user']) || empty($post['pass'])) return result(201, getLang(10034));

		$res = Db::name('seller')->where(['user' => $post['user']])->find();

		if(empty($res))
		{
			return result(201, getLang(10033));
		}

		if(checkPass($post['pass'], $res['salt']) !== $res['pass'])
		{
			return result(201, getLang(10032));
		}

		if(!$res['status'])
		{
			return result(201, getLang(10036));
		}
        
        // 设置Session过期时间为1小时
        // ini_set('session.gc_maxlifetime', 10);
        // session_set_cookie_params(10);
        // session_start();

		$token = checkPass($res['id'],$res['user']);
		Session::set('seller', ['uid' => $res['id'], 'user' => $res['user']]);
		Session::set('seller_toekn', $token);
		return result(200, getLang(10031));
	}

	public function logout()
	{
		Session::delete('seller_toekn');
		Session::delete('seller');
		return redirect('/user/login');
	}
}