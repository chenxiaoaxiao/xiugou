<?php
namespace app\index\controller;

class Base
{
	public function doamin2wid(){}

	public function checkParam($param){}
}