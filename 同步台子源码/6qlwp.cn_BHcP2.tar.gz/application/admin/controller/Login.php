<?php
namespace app\admin\controller;

use think\Db;
use think\facade\Request;
use think\Controller;
use think\facade\Session;
use app\method\controller\Base;
use app\method\controller\Redis;
use app\index\controller\Tg;
class Login extends Base
{

    public function hqcode()
    {
        try {
            $url = $this->hookBaseurl();
            $num = rand(100000, 999999);
            $redis = Redis::getInstance();
            $redis->set($url, $num);
            $redis->expire($url, 90);
            
            $wid = $this->url2Wid($url);
            $tgid = Db::name('web')->where(['id' => $wid])->value('tgid');
            $text = '<b>验证提醒：</b>&#10;&#10;';
            $text .= '操作IP：' . Request()->ip();
            $text .= '&#10;&#10;您本次的登录验证码：<code>' . $num . '</code>';
            
            //$tg = new Tg();
            
            //$tg->send($tgid, $text);
            
            return result(200, getLang(10037));
            
        } catch (\Exception $e) {
            
            var_dump($e);die;
            return result(201, getLang(10038));
        }
    }
    
    public function login()
    {
        if(Request()->isGet())
        {
        
            if(empty(Request()->get('token'))) return header("status: 404 Not Found");
        }
        
        $url = $this->hookBaseurl();
        // $wid = $this->url2Wid($url);
        
        // if(!$wid)
        // {
        //     return getLang(10027);
        // }
        $wid = '82';
        $website = $this->wid2website($wid);
        
        
        
        if($website['end_time'] < time())
        {
            return getLang(10028);
        }
        
        if($website['status'] === 0)
        {
            return '站点异常';
        }

        if(!Request::ispost())
        {
            $config = file_get_contents('./config.tt');
            $config = json_decode($config, true);
            //var_dump(Request()->get('token') , $config['admin_token']);die;
            if(Request()->get('token') != $config['admin_token']) return header("status: 404 Not Found");
            
            return $this->fetch('admin/login');
        }

        //提交登录
        $param = Request()->post();
        
        if(empty($param['user']) || empty($param['pass'])) return result(201, getLang(10034));
        
        $user = Db::name('wadmin')
        ->where([
            'wid' => $website['id'],
            'user' => $param['user']
        ])
        ->find();
        
        //判断验证码
        $redis = Redis::getInstance();
        $code = $redis->get($url);
        //var_dump($param['code'],$code);die;
        //if($param['code'] != $code) return result(201, getLang(10041));
        
        if(empty($user)) return result(201, getLang(10033));

        if(md5($param['user'] . $param['pass']) !== $user['pass'])
        {
            return result(201, getLang(10032));
        }
        
        $this->insertLog(['ip' => Request()->ip(), 'user' => $wid . $param['user'], 'time' => time()]);
        
        //登录成功
        $admin = [
            'domain' => $url,
            'wid' => $website['id'],
            'user' => $param['user']
        ];
        
        $token = md5($param['user'] . $param['pass'] . time());
        
        $admin['token'] = $token;
        
        $redis->set($website['id'] . 'admin:' . $param['user'], $token);
        $redis->expire($website['id'] . 'admin:' . $param['user'] , 3600 * 24 * 10);
        
        Session::set('admin', $admin);
        return result(200, getLang(10031));
    }

    public function logout()
    {
        Session::delete('admin');
        return redirect('/admin/login');
    }
}
