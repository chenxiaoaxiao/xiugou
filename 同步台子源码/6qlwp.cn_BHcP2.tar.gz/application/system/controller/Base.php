<?php
namespace app\system\controller;

use think\Controller;
use think\facade\Config;
use think\Db;
use think\facade\Session;

class Base extends Controller
{
	public function __construct()
	{
		parent::__construct();
		$token = getSid('system_token');

		if(empty($token))
		{
			$this->redirect('/houtai/login');
		}
	}
}