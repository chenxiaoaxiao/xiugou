<?php
namespace app\admin\controller;

use think\Db;
use think\facade\Request;
/**
* 日志管理类
*/
class Accesslog
{
	
	public function accessloglist()
	{
		$param = Request::get();

		$order = DB::name('visitlog')
		->where(['wid' => getsid('user')['wid']])
		->select();

		$count = count($order);

		$order = Db::name('visitlog')
		->where(['wid' => getsid('user')['wid']])
		->order('time', 'desc')
		->limit($param['limit'])
		->page($param['page'])
		->select();

		//$list = $order->limit($param['limit'])->page($param['page']);
		$data = [

			'code' => 0,
			'msg' => '',
			'count' => $count,
			'data' => $order
		];

		return json($data);
	}
}