<?php
namespace app\index\controller;

use think\facade\Request;
use app\method\controller\Base;
use think\Db;
class Tg extends Base
{
    public function notify()
	{
	    $param = file_get_contents("php://input");
	   // $file = fopen('tg/1.txt', 'a+');
	   // fwrite($file, $param .json_encode($_SERVER)."\r\n\r\n\r\n");
	   // fclose($file);
	    
	    $param = json_decode($param, true);
	    
	    if(!isset($param['message']['text'])) die;
	    
	    if($param['message']['text'] === "/id" || $param['message']['text'] === "/start")
	    {
	        $this->send($param['message']['from']['id'], '您的ID:   <code>' . $param['message']['from']['id'] . '</code>');
	    }
	}
	
	public function send($id, $text)
	{
	    $token = '6683271923:AAFDlnJLn15-7zjpLHcER-4FW9rWQrFthYY';
        
        $param = [
            
            'parse_mode' => 'HTML',
            'chat_id' => $id,
            'text' => $text
        ];
        
        $url = 'https://api.telegram.org/bot'.$token.'/sendMessage';
        return curl_post($url,$param);
	}
}