<?php
namespace app\method\controller;

use think\facade\Request;
use think\Controller;
use think\Db;
/**
* 公共类
*/
class Base extends Controller
{

	public $redis;

	public function __construct()
	{
		//$this->redis = new \app\method\controller\Redis();
	}
	
	public function insertLog($arr)
	{
	    $arr['agent'] = Request()->header('user-agent');
	    Db::name('adminlog')->insert($arr);
	}

	/**
	 * 获取用户访问的顶级域名
	 */
	public function hookBaseurl1()
	{
		$url = Request()->host();
		$arr = explode('.', $url);
		return $arr[count($arr)-2] . '.' . $arr[count($arr)-1];
	}
	
	/*
	* 获取顶级域名
	*/
	
	public function hookBaseurl()
	{
	    $url = Request()->host();
        $host = $url;
        // 如果主机名是 IP 地址，则直接返回 IP 地址
        if(filter_var($host, FILTER_VALIDATE_IP)) {
            return $host;
        }
        // 如果主机名不是 IP 地址，则返回顶级域名
        $parts = explode('.', $host);
        $num_parts = count($parts);
        if($num_parts == 2) { // 只有二级域名
            return $host;
        } else { // 三级以上的域名
            $domain = $parts[$num_parts - 2] . '.' . $parts[$num_parts - 1];
            return $domain;
        }
	}

	/**
	 * 获取用户访问真实域名
	 * @return string domain
	 */
	public function hookDomain()
	{
		$domain = Request::domain();

		if(Request::isSsl())
		{
			$domain = str_replace('https://', '', $domain);
		}else{

			$domain = str_replace('http://', '', $domain);
		}

		return $domain;
	}

	/**
	 * url 取站点id
	 */
	public function url2Wid($url, $bool = false)
	{
	    $wid = Db::name('domainlog')->where(['domain' => $url])->value('wid');
	    $wid = '82';
		return empty($wid) ? false : $wid;
	}

	/**
	 * 站点id取站点信息
	 */
	public function wid2website($wid)
	{
	    $res = Db::name('web')->where(['id' => $wid])->find();
		return empty($res) ? false : $res;
	}

	/**
	 * Url 取站点信息
	 */
	/*public function Url2Website($url)
	{

		//var_dump($this->redis);die;
		$res = $this->redis->mgethash('domain', $url);
		return $res ? json_decode($res, true) : false;
	}*/

	/**
	 * 站点ID取站点详细信息
	 */
	/*public function wid2Website($wid)
	{
		$res = $this->redis->mgethash('website', $wid);
		return $res ? json_decode($res, true) : false;
	}*/

	/*public function insertLog()
	{
		$data = [

			'ip' => Request()->ip(),
			'os' => get_os(),
			'referer' => Request()->domain(),
			'agent' => Request()->header('user-agent'),
			'address' => ipToAddress(Request()->ip()),
			'time' => time()
		];


		(new \app\method\controller\Sql())->insertVisitLog('visitlog', $data);
	}*/
}