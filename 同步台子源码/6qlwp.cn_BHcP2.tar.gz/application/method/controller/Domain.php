<?php
namespace app\method\controller;

/**
* 域名操作类
*/
class Domain
{

	/**
	 * 获取域名后缀
	*/
	public function searchf()
	{
		
	}
}