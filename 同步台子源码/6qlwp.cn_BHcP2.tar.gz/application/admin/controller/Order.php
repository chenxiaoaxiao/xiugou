<?php
namespace app\admin\controller;

use think\Db;
use think\facade\Request;
use think\facade\Session;
use app\admin\controller\Base;
use \GatewayWorker\Lib\Gateway;
class Order extends Base 
{

    /**
     * 拉黑数据
     */
    public function block()
    {
        $oid = Request()->get('id');
    }
    
    public function upsort()
    {
        $param = Request()->post();
        Db::name('uspeech')->where(['id' => $param['oid']])->update(['sort' => $param['sort']]);
        
        return result(200, getLang(10013));
    }
    
    public function zhiding()
    {
        $oid = Request()->get('id');
        Db::startTrans();
        try {

            //$wid = Session::get('admin')['wid'];
            Db::name('list')->where(['id' => $oid])->update(['orderaes' => time()]);
            

            Db::commit();

            return result(200, getLang(10042));

        } catch (\Exception $e) {
            Db::rollback();
            WriteExceptionInformation($e);
            return result(201, getLang(10030));
        }
    }
    
    public function catcard()
    {
        $id = Request()->get('id');
        $wid = Session::get('admin')['wid'];
        $order = Db::name('list')->where(['wid' => $wid, 'id' => $id])->find();
        if(empty($order))
        {
            return '数据为空';
        }
        
        $this->assign('order', $order);
        return $this->fetch('admin/catcard');
    }

    /**
     * 拉黑访问
     */
    public function VisitBlock()
    {
        $param = Request()->get();
        $wid = Session::get('admin')['wid'];
        $where = ['wid' => $wid, 'id' => $param['id']];
        Db::name('visitlog')->where($where)->update(['status' => $param['type']]);

        return result(200, getLang(10013));

    }

    /**
     * 删除当前站点所有访问日志 除黑名单外
     */
    public function delAllVisit()
    {   
        $param = Request()->get();
        $wid = Session::get('admin')['wid'];
        $where = ['wid' => $wid, 'status' => $param['type']];

        Db::name('visitlog')->where($where)->delete();

        return result(200, getLang(10014));
    }

    /**
     * 删除一条访问日志
     */
    public function delvisit()
    {
        $id = Request()->get('id');
        $wid = Session::get('admin')['wid'];
        Db::name('visitlog')->where(['id' => $id, 'wid' => $wid])->delete();
        return result(200, getLang(10014));
    }

    /**
     * 删除所有数据
     */
    public function delAllOrder()
    {
        $oid = Request()->get('id');
        Db::startTrans();
        try {

            $wid = Session::get('admin')['wid'];
            $data = Db::name('list')->where(['wid' => $wid])->field('id', true)->select();
            if(!Db::name('delete')->insertAll($data))
            {
                Db::rollback();
                return result(201, getLang(10030));
            }

            if(!Db::name('list')->where(['wid' => $wid])->delete())
            {
                Db::rollback();
                return result(201, getLang(10030));
            }

            Db::commit();

            return result(200, getLang(10014));

        } catch (\Exception $e) {
            
            //var_dump($e->getMessage());die;
            Db::rollback();
            WriteExceptionInformation($e);
            return result(201, getLang(10030));
        }
    }

    /**
     * 删除一条数据
     */
    public function delorder()
    {
        
        $oid = Request()->get('id');
        Db::startTrans();
        try {

            $wid = Session::get('admin')['wid'];
            $data = Db::name('list')->where(['id' => $oid, 'wid' => $wid])->field('id', true)->find();
            if(!Db::name('delete')->insert($data))
            {
                Db::rollback();
                return result(201, getLang(10030));
            }

            if(!Db::name('list')->delete($oid))
            {
                Db::rollback();
                return result(201, getLang(10030));
            }

            Db::commit();

            return result(200, getLang(10014));

        } catch (\Exception $e) {
            Db::rollback();
            WriteExceptionInformation($e);
            return result(201, getLang(10030));
        }
    }

    /**
     * 更新数据状态
     */
	public function upstatus()
	{
		$param = Request::post();

        if(empty($param['status']) || empty($param['oid']))
        {
            return result(201, 'error');
        }

        $res = Db::name('list')
        ->where(['id' => $param['oid']])
        ->update([

            'status' => $param['status']
        ]);

        if($res)
        {
            $speech = Db::name('uspeech')->where(['id' => $param['status']])->field('content,page,title')->find();
            $arr = [
                'page' => $speech['page'],
                'status' => $param['status'],
                'title' => $speech['title'],
                'content' => $speech['content']
            ];
            Gateway::sendToUid((int)$param['oid'], json_encode(['method' => 'update', 'data' => $arr]));
            return result(200, getLang(10013));

        }else{
            return result(201, getLang(10001));
        }
	}
}