<?php
namespace app\method\controller;

use think\Db;

/**
 * Redis 操作类
 */
class Redis {
    private $redis;
    private static $instance;

    private function __construct($host, $port, $pass) {
        $this->redis = new \Redis();
        $this->redis->connect($host, $port);
        $this->redis->auth($pass);
    }

    /*
     * 通过静态方法获取 RedisClient 的单例
     */
    public static function getInstance() {
        
        $host = Config('redis.host');

		$port = Config('redis.port');

		$pass = Config('redis.pass');
		
        if (!self::$instance) {
            self::$instance = new Redis($host, $port, $pass);
        }
        return self::$instance;
    }

    /* STRING commands */
    public function set($key, $value, $expire = null) {
        $value = json_encode($value);

        $result = $this->redis->set($key, $value);
        if ($expire !== null) {
            $this->redis->expire($key, $expire);
        }
        return $result;
    }

    public function get($key) {
        $value = $this->redis->get($key);
        return json_decode($value, true);
    }

    public function del($key) {
        return $this->redis->del($key);
    }

    /* HASH commands */
    public function hset($key, $field, $value) {
        $this->redis->hset($key, $field, $value);
    }

    public function hget($key, $field) {
        return $this->redis->hget($key, $field);
    }

    /* LIST commands */
    public function lpush($key, $value) {
        $this->redis->lpush($key, $value);
    }

    public function rpop($key) {
        return $this->redis->rpop($key);
    }

    /* SET commands */
    public function sadd($key, $member) {
        $this->redis->sadd($key, $member);
    }

    public function smembers($key) {
        return $this->redis->smembers($key);
    }

    /* Sorted Set commands */
    public function zadd($key, $score, $member) {
        $this->redis->zadd($key, $score, $member);
    }

    public function zrange($key, $start, $stop, $withscores = false) {
        return $this->redis->zrange($key, $start, $stop, $withscores);
    }

    /* Other commands */
    public function exists($key) {
        return $this->redis->exists($key);
    }

    public function expire($key, $ttl) {
        return $this->redis->expire($key, $ttl);
    }

    public function ttl($key) {
        return $this->redis->ttl($key);
    }
    
    public function incr($key) {
        return $this->redis->incr($key);
    }

    /*
     * 禁止克隆 RedisClient 实例
     */
    private function __clone() {}

    /*
     * 关闭连接
     */
    public function close() {
        $this->redis->close();
    }
}
