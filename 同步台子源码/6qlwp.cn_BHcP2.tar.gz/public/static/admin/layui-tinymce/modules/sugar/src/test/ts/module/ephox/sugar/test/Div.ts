import { SugarElement } from 'ephox/sugar/api/node/SugarElement';

export default (): SugarElement<HTMLDivElement> => SugarElement.fromTag('div');
