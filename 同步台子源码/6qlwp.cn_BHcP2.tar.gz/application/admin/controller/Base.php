<?php
namespace app\admin\controller;

use think\Controller;
use think\facade\Session;
use think\Db;
use app\method\controller\Redis;
class Base extends Controller
{
	/**
	 * 1. 拿到用户访问域名
	 * 1.5 通过域名判断是否存在站点信息和token
	 * 2. 通过域名匹配相应站点
	 * 3. 判断站点状态
	 * 4. 判断登录
	 */
	public function __construct()
	{
		parent::__construct();
		//判断当前域名是否登录
		
		$admin = Session::get('admin');
		if(empty($admin))
		{
			$this->redirect('/admin/login');
		}else{
		    $redis = Redis::getInstance();
		    
		    $token = $redis->get($admin['wid'] . "admin:" . $admin['user']);
		    
		    //var_dump($token, $admin['token']);die;
		    if(!$token || $admin['token'] !== $token)
		    {
		        $this->redirect('/admin/login');
		    }
		}
	}
	
	public function webStatus()
	{
	    $wid = Session::get('admin')['wid'];
	    
	    $web = Db::name('web')->where(['id' => $wid])->field('status,end_time')->find();
	    
	    if((int)$web['status'] === 0 || $web['end_time'] < time())
	    {
	        //Session::delete('admin');
            $this->redirect('/admin/login');
	    }
	}
	
	/**
	 * url 取站点id
	 */
	public function url2Wid($url, $bool = false)
	{
	   // if($bool)
	   // {
	   //    $wid = Db::name('domain')->where(['domain' => $url])->field('wid,')->find();
	   //    $res = Db::name('website')->where(['id' => $wid])->field('id,');
		  //  return empty($wid) ? false : $wid; 
	   // }
	    
	    $wid = Db::name('domainlog')->where(['domain' => $url])->value('wid');
	    $wid = '82';
		return empty($wid) ? false : $wid;
	}


}