<?php
namespace app\index\controller;
use think\Db;
use think\Request;

/**
* 数据类
*/
class Order extends Base
{
	
	function __construct(argument)
	{
		# code...
	}

	
}