<?php
namespace app\system\controller;

use think\Controller;
use think\facade\Request;
use think\Db;
use think\facade\Session;
class Login extends Controller
{
	public function index()
	{
	    //if(Request()->get('t') != 'shangyin') return header("status: 404 Not Found");
		if(Request::ispost()){
			return $this->login();
		}

		return $this->fetch('system/login');
	}

	public function login()
	{
		$post = Request::post();
		if(empty($post['user']) || empty($post['pass'])) return result(201, getLang(10034));

		$res = Db::name('admin')->where(['user' => $post['user']])->find();

		if(empty($res))
		{
			return result(201, getLang(10033));
		}

		if(checkPass($post['pass'], $res['salt']) !== $res['pass'])
		{
			return result(201, getLang(10032));
		}

		$token = checkPass($res['id'],$res['user']);
		Session::set('system_token', $token);
		return result(200, getLang(10031));
	}

	public function logout()
	{
		Session::delete('system_token');
		return redirect('/houtai/login');
	}
}